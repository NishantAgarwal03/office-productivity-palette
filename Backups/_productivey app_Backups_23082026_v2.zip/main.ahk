; ======================================================================================================================
; Title:   Office Productivity Hub (Modular Edition)
; Version: 1.0.0 (Production Release)
; AHK Ver: v2.0+
; OS:      Windows 10 / 11
;
; Core Purpose:
; A bulletproof, keyboard-driven Windows office productivity hub that unifies 50+ essential tools,
; instant date/text/math transformations, and on-the-fly snippet expansion into a fast, non-blocking
; Command Palette and Leader-Key interface.
; ======================================================================================================================

#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent(true)

; --- Global State & Configuration ---
global AppTitle          := "Office Productivity Hub"
global AppVersion        := "1.0.0"
global DataDir           := A_ScriptDir
global SnippetsFile      := DataDir . "\office_productivity_snippets.csv"
global ErrorLogFile      := DataDir . "\office_productivity_errors.log"

global BuiltInActions    := []          ; Array of built-in action objects
global CustomSnippets    := []          ; Array of user-defined snippet objects
global RegisteredTriggers := Map()      ; Active hotstring triggers map

global PaletteGui        := ""
global PaletteSearch     := ""
global PaletteListView   := ""
global PaletteStatus     := ""
global PaletteItems      := []
global TargetWindowHwnd  := 0

global ManagerGui        := ""
global ManagerListView   := ""
global ManagerSearch     := ""
global ManagerStatus     := ""
global ManagerPos        := {x: 100, y: 100, w: 720, h: 420}

global LeaderActive      := false
global LastShiftTime     := 0
global LastExecutedAction := ""
global LastCtrlTime      := 0           ; Timestamp for Double-Ctrl detection

; --- Modular Component Inclusions ---
#Include "Lib\Core.ahk"
#Include "Lib\PaletteGui.ahk"
#Include "Lib\ManagerGui.ahk"
#Include "Lib\Actions_DateTime.ahk"
#Include "Lib\Actions_Text.ahk"
#Include "Lib\Actions_Email.ahk"
#Include "Lib\Actions_Math.ahk"
#Include "Lib\Actions_Utility.ahk"
#Include "Lib\Actions_Extraction.ahk"
#Include "Lib\Actions_Finance.ahk"
#Include "Lib\ActionBoardGui.ahk"

; Initialize App
InitApp()

InitApp() {
    try {
        RegisterDateTimeActions()
        RegisterTextActions()
        RegisterEmailActions()
        RegisterMathActions()
        RegisterUtilityActions()
        RegisterExtractionActions()
        RegisterFinanceActions()
        RegisterActionBoardActions()

        LoadCustomSnippets()
        InitActionBoardEngine()
        RegisterDynamicHotstrings()
    } catch as err {
        LogAppError("InitApp", err)
        MsgBox("Failed to initialize Office Productivity Hub:`n`n" . err.Message, AppTitle . " - Init Error", "Icon!")
    }
}

; ======================================================================================================================
;                                             GLOBAL HOTKEYS & TRIGGERS
; ======================================================================================================================

; --- Ambient Selection Tooltip Watcher ---
global DragStartX := 0
global DragStartY := 0

; --- Non-Invasive Mouse Drag Selection Detector ---
~LButton::
{
    global DragStartX, DragStartY
    CoordMode("Mouse", "Screen")
    MouseGetPos(&DragStartX, &DragStartY)
}

~LButton Up::
{
    global DragStartX, DragStartY
    CoordMode("Mouse", "Screen")
    MouseGetPos(&endX, &endY)
    ; If mouse moved more than 25 pixels horizontally or 15 pixels vertically, it's a drag selection
    if (Abs(endX - DragStartX) > 25 || Abs(endY - DragStartY) > 15) {
        ToolTip("📌 Task Detected — Double-tap Ctrl to add to Action Board")
        SetTimer(() => ToolTip(), -2500)
    }
}

; --- Repeat Last Action (Win + 0 / Ctrl + 0) ---
#0::RepeatLastAction()
^0::RepeatLastAction()

; --- 1. Universal Command Palette: Double-Shift (JetBrains / IntelliJ Style) ---
~LShift Up::
~RShift Up::
{
    global LastShiftTime
    ; Only trigger if Shift was tapped alone (no other key pressed during hold)
    if (A_PriorKey = "LShift" || A_PriorKey = "RShift") {
        if (A_TickCount - LastShiftTime < 350) {
            LastShiftTime := 0
            ShowCommandPalette()
            return
        }
        LastShiftTime := A_TickCount
    } else {
        LastShiftTime := 0
    }
}

; Fallback / Alternative Hotkeys for Palette
^Space::ShowCommandPalette()
#+Space::ShowCommandPalette()

; --- Double-Ctrl: Instant Task / Commitment Capture ---
~LCtrl Up::
~RCtrl Up::
{
    global LastCtrlTime
    diff := A_TickCount - LastCtrlTime
    if (diff > 50 && diff < 450) {
        LastCtrlTime := 0
        CaptureSelectedTextAsTask()
    } else {
        LastCtrlTime := A_TickCount
    }
}

; --- Action Board Hotkeys (Win + T / Ctrl + Shift + T) ---
#t::ToggleActionBoard()
#+t::ToggleActionBoard()
^+t::CaptureSelectedTextAsTask()

; --- 2. Instant Highlight & Save (Ctrl + Shift + H) ---
^+h::CaptureSelectedTextAsSnippet()

; --- 3. Visual Snippet Manager (Win + Esc) ---
#Esc::ToggleManagerGui()

; --- 4. Leader Key Chords (Ctrl + ;) ---
#HotIf !WinActive("ahk_exe EXCEL.EXE")
^;::ActivateLeaderKey()
#HotIf

; --- 5. Context Hotkeys ---
#HotIf HasPaletteResults()
    1::PaletteExecuteSelection(1)
    2::PaletteExecuteSelection(2)
    3::PaletteExecuteSelection(3)
    4::PaletteExecuteSelection(4)
    5::PaletteExecuteSelection(5)
    6::PaletteExecuteSelection(6)
    7::PaletteExecuteSelection(7)
    8::PaletteExecuteSelection(8)
    9::PaletteExecuteSelection(9)

    Numpad1::PaletteExecuteSelection(1)
    Numpad2::PaletteExecuteSelection(2)
    Numpad3::PaletteExecuteSelection(3)
    Numpad4::PaletteExecuteSelection(4)
    Numpad5::PaletteExecuteSelection(5)
    Numpad6::PaletteExecuteSelection(6)
    Numpad7::PaletteExecuteSelection(7)
    Numpad8::PaletteExecuteSelection(8)
    Numpad9::PaletteExecuteSelection(9)
#HotIf

#HotIf IsPaletteActive()
    Up::PaletteNavigate(-1)
    Down::PaletteNavigate(1)
    Enter::PaletteExecuteSelection()
    Escape::CloseCommandPalette()
#HotIf

#HotIf IsManagerActive()
    Del::ManagerDeleteItem()
    F2::ManagerEditItem()
#HotIf

#HotIf IsActionBoardActive() && !IsInputTaskBoxFocused()
    1::MatrixMoveSelectedTask("Q1")
    2::MatrixMoveSelectedTask("Q2")
    3::MatrixMoveSelectedTask("Q3")
    4::MatrixMoveSelectedTask("Q4")
    Space::MatrixToggleDone()
    v::ShowFullTaskViewModal()
    Del::MatrixDeleteSelectedTask()
#HotIf

#HotIf IsInputTaskBoxFocused()
    Enter::HandleMatrixEnterKey()
#HotIf
