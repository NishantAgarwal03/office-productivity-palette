# ⚡ Office Productivity Command Palette & Visual Action Hub (v2.0.0 Production Release)

> **Core Purpose:** A bulletproof, keyboard-driven Windows office productivity hub that unifies 70+ essential tools, instant data extraction, Indian financial & GST analytics, 4-Quadrant visual Eisenhower matrix board, automatic file sync, weekly backups, and on-the-fly snippet expansion.

---

## 🚀 Master Shortcuts Reference

| Shortcut                              | Action                           | Description                                                                              |
| ------------------------------------- | -------------------------------- | ---------------------------------------------------------------------------------------- |
| **`Win + T`** / **`Win + Shift + T`** | **📋 Visual Action Board**       | 4-Quadrant Eisenhower Matrix Grid with native dark theme & custom-draw colors            |
| **`Double-Shift`**                    | **🔍 Universal Command Palette** | JetBrains-style spotlight search across all 70+ built-in actions & snippets              |
| **`Double-Ctrl`**                     | **📌 Commitment Catcher**        | Instantly captures mouse-highlighted text into Action Board                              |
| **`Win + 0`** / **`Ctrl + 0`**        | **🔁 Repeat Last Action**        | Instantly re-executes the most recently used transformation or tool                      |
| **`Win + Esc`**                       | **⚡ Snippet Manager**            | Visual GUI to create, search, and manage text expansion abbreviations                    |
| **`Ctrl + Shift + H`**                | **💾 Quick Highlight & Save**    | Saves selected text as an instant hotstring snippet                                      |
| **`Ctrl + ;`**                        | **⚡ Leader Key Mode**            | Chords: `d`=Date, `t`=Timestamp, `u`=Upper, `l`=Lower, `c`=Calc, `v`=PasteRaw, `w`=Words |
| **`1` .. `9`**                        | **Instant Numeric Execution**    | In Command Palette, tap `1`..`9` to run the corresponding result immediately             |
| **`Trigger + Space`**                 | **Direct Hotstring Expansion**   | Expands saved trigger keywords directly in text (e.g. `myemail `, `myphone `)            |

---

## 🖥️ The 6 Integrated User Interfaces of the Eisenhower System

```
                      ┌────────────────────────────────────────────────────────┐
                      │ 1. 4-Quadrant Matrix Board (Win + T)                   │
                      │ 4 spatial quadrants, custom-draw BGR colors, 2-line    │
                      │ continuous white preview ribbon & cue banner input     │
                      └──────────────────────────┬─────────────────────────────┘
                                                 │
            ┌────────────────────────────────────┼────────────────────────────────────┐
            │                                    │                                    │
            ▼                                    ▼                                    ▼
┌────────────────────────┐           ┌────────────────────────┐           ┌────────────────────────┐
│ 2. Command Palette     │           │ 3. Snippet Manager     │           │ 4. Commitment Classifier│
│ Double-Shift Spotlight │           │ Win + Esc CRUD GUI     │           │ Top-Left 16pt pill     │
│ Dynamic 1..9 execution │           │ Search & CSV sync      │           │ 6 semantic action chips│
└────────────────────────┘           └────────────────────────┘           └───────────┬────────────┘
                                                                                      │ (After Type Assigned)
                                                                                      ▼
┌────────────────────────┐                                                ┌────────────────────────┐
│ 6. Q1 Urgent Nudge HUD │ ◄───────────────────────────────────────────── │ 5. Prioritizer Mini-Pill│
│ Floating ~3" from mouse│           (Periodic Urgency Engine)            │ Top-Left 16pt pill     │
│ Bold <2s glanceable HUD│                                                │ 4 Matrix-colored chips │
└────────────────────────┘                                                └────────────────────────┘
```

### 1. UI 1: 4-Quadrant Visual Eisenhower Matrix Board (`Win + T`)

* **Frameless Obsidian Dark Interface (`#121212`):** Frameless, window-draggable anywhere on screen via `WM_NCLBUTTONDOWN`.
* **Native Cue Banner Input Bar:** `➕ Type a new task and press Enter (or search to filter)...` via Win32 `EM_SETCUEBANNER`.
* **Win32 `NM_CUSTOMDRAW` Color-Coded Items:**
  * **Unassigned Tasks (`[NEW]`):** Rendered in **Crisp Pure White (`#FFFFFF`)**.
  * **Q1 (Do First):** Rendered in **Coral Red (`#FF5252`)**.
  * **Q2 (Schedule):** Rendered in **Sky Blue (`#40C4FF`)**.
  * **Q3 (Quick Win):** Rendered in **Golden Amber (`#FFD54F`)**.
  * **Q4 (Backlog):** Rendered in **Mint Green (`#69F0AE`)**.
* **Clean 2-Line Continuous Bottom Ribbon:**
  * **Line 1:** Continuous single-line unclipped task text in pure white (`#FFFFFF`).
  * **Line 2:** Fixed-position metadata `[Status: PENDING | Quadrant: Q1 | Type: Deadline | Created: ...]`.
  * **Line 3:** Keyboard shortcut guide.

### 2. UI 2: Universal Spotlight Command Palette (`Double-Shift` / `Ctrl + Space`)

* **Accordion Dynamic Height:** Minimalist single search bar when empty (`56px`); expands dynamically as search results appear.
* **Instant Numeric Hotkeys:** Tap keys `1` through `9` on standard keyboard or Numpad for instant 0-second tool execution.
* **Fuzzy Multi-Keyword Search:** Matches action name, category, description, and keywords.

### 3. UI 3: Visual Snippet & Replacement Manager (`Win + Esc`)

* **Full CRUD & Filter Bar:** Create, edit, delete, and toggle snippets on the fly with live search.
* **CSV Import & Export:** One-click backup and restore of custom abbreviations.

### 4. UI 4: Commitment Classifier Mini-Pill (Top-Left)

* **📍 Position:** Fixed at **Top-Left** of your active screen (`x: +25, y: +25`).
* **📖 80% Task Prominence:** Task text rendered in **`16pt` Bold White** for effortless reading.
* **🌈 6 Semantic Colored Action Chips (`10pt` Bold):**
  * `[ 📦 1 Deliver ]` $\rightarrow$ Cyan (`#64D2FF` on `#182E38`)
  * `[ 🤝 2 Promise ]` $\rightarrow$ Periwinkle Blue (`#82AAFF` on `#1E2238`)
  * `[ ⏰ 3 Deadline ]` $\rightarrow$ Coral Rose (`#FF757F` on `#381818`)
  * `[ 🔄 4 Follow  ]` $\rightarrow$ Warm Gold (`#FFC777` on `#302414`)
  * `[ 🔍 5 Review  ]` $\rightarrow$ Lavender Purple (`#C099FF` on `#281838`)
  * `[ ⚡ 6 Quick   ]` $\rightarrow$ Mint Teal (`#73DACA` on `#143022`)
* **⏱️ Auto-Dismiss:** Snoozes and closes automatically after **10 seconds** of inactivity.

### 5. UI 5: Quadrant Prioritizer Mini-Pill (Top-Left)

* **📍 Position & Symmetry:** Top-Left (`x: +25, y: +25`), sharing exact symmetrical layout with UI 4.
* **📖 Task with Classified Badge:** `🎯 [⏰ Deadline] Task Description...` in **`16pt` Bold White**.
* **🌈 4 Spatial Matrix Chips (`10pt` Bold):**
  * `[ 🔥 1 DO FIRST  ]` $\rightarrow$ **Coral Red** (`#FF5252` on `#321414`)
  * `[ 📅 2 SCHEDULE  ]` $\rightarrow$ **Sky Blue** (`#40C4FF` on `#102232`)
  * `[ ⚡ 3 QUICK WIN ]` $\rightarrow$ **Golden Amber** (`#FFD54F` on `#2E2210`)
  * `[ ⏳ 4 BACKLOG   ]` $\rightarrow$ **Mint Green** (`#69F0AE` on `#122818`)
* **⏱️ Auto-Dismiss:** Snoozes and closes automatically after **10 seconds** of inactivity.

### 6. UI 6: Q1 High-Priority Urgent Nudge (Cursor-Relative HUD)

* **📍 Position:** Dynamically spawns **~3 inches (~260px)** to the right of your mouse cursor.
* **🛡️ Smart Screen Boundary Clamping:** Detects active monitor; flips to left of cursor or clamps `20px` inside screen edge if near a boundary so it **never goes off-screen**.
* **⚡ <2-Second Glanceable Format:**
  * **Header (`8pt` Bold Coral Red):** `🔥 Q1 URGENT (2 Active)`
  * **Items (`12pt` Bold Crisp White):** Top 2 urgent items truncated cleanly for instant peripheral reading.
* **⏱️ Auto-Dismiss:** Displays for **2.5 seconds** and vanishes without stealing focus.

---

## 🏛️ Catalog of All Built-In Office Features & Examples

### 🔍 1. Text Mining & Data Extraction Suite (7 Tools)

| #   | Tool Name                          | Shortcut | Output / Behavior                                                             | Example                                                                                                                                       |
| --- | ---------------------------------- | -------- | ----------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | **Extract All Email Addresses**    | `[1]`    | Pulls clean list of all valid email addresses.                                | **Input:** `"Contact john@test.com or billing@corp.in"`<br>**Output:** `john@test.com`<br>`billing@corp.in`                                   |
| 2   | **Extract All URLs & Web Links**   | `[2]`    | Pulls clean list of all web URLs and links.                                   | **Input:** `"See https://incometax.gov.in and www.gst.gov.in"`<br>**Output:** `https://incometax.gov.in`<br>`http://www.gst.gov.in`           |
| 3   | **Extract Phone & Mobile Numbers** | `[3]`    | Pulls 10-digit Indian mobiles and landlines.                                  | **Input:** `"Call +91 98765-43210 or 022-24567890"`<br>**Output:** `+91 98765 43210`<br>`022-24567890`                                        |
| 4   | **Extract Indian GSTINs**          | `[4]`    | Validates and extracts 15-character GST numbers.                              | **Input:** `"Vendor GSTIN: 27ABCDE1234F1Z5 for Maharashtra"`<br>**Output:** `27ABCDE1234F1Z5`                                                 |
| 5   | **Extract Indian PAN Numbers**     | `[5]`    | Validates and extracts 10-character PANs.                                     | **Input:** `"Director PAN is ABCDE1234F on filing"`<br>**Output:** `ABCDE1234F`                                                               |
| 6   | **Extract All Dates from Text**    | `[6]`    | Pulls all dates in any format; tags invalid calendar dates with `[INVAL]`.    | **Input:** `"Dates: 21-Aug-2026, 31/02/2026, 99/99/9999"`<br>**Output:**<br>`21-Aug-2026`<br>`31/02/2026 [INVAL]`<br>`99/99/9999 [INVAL]`     |
| 7   | **Date Difference & Working Days** | `[7]`    | Calculates total calendar and working days (Mon–Fri) from dates or sentences. | **Input:** `"Work starts on 21-Aug-2026 and finishes on 31-Aug-2026."`<br>**Output:** `Total Days: 10 days \| Working Days (Mon-Fri): 7 days` |

---

### 💼 2. Indian Fiscal & Financial Analytics (8 Tools)

| #   | Tool Name                             | Shortcut | Output / Behavior                                                    | Example                                                                                                                          |
| --- | ------------------------------------- | -------- | -------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------- |
| 8   | **Indian Financial Year & Quarter**   | `↵`      | Converts any date or sentence into Indian Fiscal Year format.        | **Input:** `"Audit on 21-Aug-2026"` $\rightarrow$ `FY 2026–27 (Q2)`<br>**Input:** `15-Jan-2027` $\rightarrow$ `FY 2026–27 (Q4)`  |
| 9   | **Percentage vs Point (pp) Change**   | `↵`      | Compares two rates with percentage and percentage-point deltas.      | **Input:** `5.0% 6.5%`<br>**Output:** `+1.50 pp (+30.00%)`                                                                       |
| 10  | **CAGR Growth Calculator**            | `↵`      | Calculates CAGR from raw numbers or natural sentences.               | **Input:** `"Investment increased from ₹10,00,000 to ₹20,00,000 over 5 years."`<br>**Output:** `CAGR: 14.87% \| Multiple: 2.00x` |
| 11  | **Reverse GST Calculator (18%)**      | `↵`      | Extracts Taxable Base + 18% GST (CGST/SGST) from amount or sentence. | **Input:** `"invoice total including 18% GST is ₹1,18,000."`<br>**Output:** `Taxable Base: ₹1,00,000.00 \| GST: ₹18,000.00`      |
| 12  | **Reverse GST (Custom Rate)**         | `↵`      | Extracts Taxable Base + Tax for custom rate (e.g. 5%, 12%, 28%).     | **Input:** `"Inclusive amount = ₹1,18,000 > GST = 12%"`<br>**Output:** `Base: ₹1,05,357.14 \| GST (12%): ₹12,642.86`             |
| 13  | **Clean Number to Raw Machine Value** | `↵`      | Normalizes verbal units, European decimals, and commas.              | **Input:** `1.25 Lakh`<br>**Output:** `125000`<br>**Input:** `1.250,50 €`<br>**Output:** `1250.50`                               |
| 14  | **Format with Indian Commas**         | `↵`      | Formats number with Indian comma grouping (Lakhs/Crores).            | **Input:** `12345678`<br>**Output:** `1,23,45,678.00`                                                                            |
| 15  | **Format with International Commas**  | `↵`      | Formats number with standard 3-digit comma grouping.                 | **Input:** `12345678`<br>**Output:** `12,345,678.00`                                                                             |

---

### 📋 3. Commitment Catcher & Visual Task Board (4 Tools)

| #   | Tool Name                               | Shortcut      | Output / Behavior                                                              |
| --- | --------------------------------------- | ------------- | ------------------------------------------------------------------------------ |
| 16  | **Open Action Board (Eisenhower Grid)** | `Win + T`     | Opens the visual 4-Quadrant Eisenhower Matrix grid.                            |
| 17  | **Capture Selected Text as Task**       | `Double-Ctrl` | Saves highlighted text as an action item into `office_productivity_tasks.csv`. |
| 18  | **Export Tasks to CSV / Backup**        | `↵`           | Creates an on-demand timestamped snapshot in `Backups/`.                       |
| 19  | **Import Tasks from External CSV**      | `↵`           | Imports and deduplicates tasks from any external CSV.                          |

---

### 📅 4. Date & Time Master (10 Tools)

| #   | Tool Name                   | Shortcut       | Output Preview / Behavior                    | Example Output             |
| --- | --------------------------- | -------------- | -------------------------------------------- | -------------------------- |
| 20  | **Today's ISO Date**        | `^; d` / `[1]` | Inserts standard ISO date (`YYYY-MM-DD`).    | `2026-08-23`               |
| 21  | **Compact File Timestamp**  | `^; t` / `[2]` | Inserts compact timestamp (`YYMMDD_HHMMSS`). | `260823_114500`            |
| 22  | **Formal Long Date**        | `[3]`          | Inserts full weekday, month, day, and year.  | `Sunday, August 23, 2026`  |
| 23  | **Current Time (12-Hour)**  | `[4]`          | Inserts 12-hour clock with AM/PM.            | `11:45 AM`                 |
| 24  | **Current Time (24-Hour)**  | `[5]`          | Inserts 24-hour military clock with seconds. | `11:45:22`                 |
| 25  | **Tomorrow's Date**         | `[6]`          | Calculates and inserts tomorrow's date.      | `2026-08-24`               |
| 26  | **Yesterday's Date**        | `[7]`          | Calculates and inserts yesterday's date.     | `2026-08-22`               |
| 27  | **Current ISO Week Number** | `[8]`          | Inserts sprint/work-week string.             | `Week 34, 2026`            |
| 28  | **Current Month & Year**    | `[9]`          | Inserts billing period title.                | `August 2026`              |
| 29  | **Work Week Date Range**    | `↵`            | Inserts Monday-to-Friday range.              | `2026-08-17 to 2026-08-21` |

---

### 🔤 5. Text Formatting & Case Transformers (10 Tools)

| #   | Tool Name                            | Shortcut | Transformation Applied                                       | Detailed Before & After Example                                                                                                                                                                                                                            |
| --- | ------------------------------------ | -------- | ------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 30  | **Paste Clean Plain Text**           | `^; v`   | Strips all HTML/rich styling, colors, and font formatting.   | **Input (Styled Clipboard):** `<b><font color="#FF0000">Invoice Total: $1,500</font></b>`<br>**Output (Pasted Plain Text):** `Invoice Total: $1,500`                                                                                                       |
| 31  | **Convert to UPPERCASE**             | `^; u`   | Converts selected text to all capital letters.               | **Input:** `quarterly statutory compliance report`<br>**Output:** `QUARTERLY STATUTORY COMPLIANCE REPORT`                                                                                                                                                  |
| 32  | **Convert to lowercase**             | `^; l`   | Converts selected text to all small letters.                 | **Input:** `GOODS AND SERVICES TAX IDENTIFICATION NUMBER`<br>**Output:** `goods and services tax identification number`                                                                                                                                    |
| 33  | **Convert to Title Case**            | `↵`      | Capitalizes the first letter of each word.                   | **Input:** `annual general meeting of directors and shareholders`<br>**Output:** `Annual General Meeting Of Directors And Shareholders`                                                                                                                    |
| 34  | **Convert to Sentence case**         | `↵`      | Capitalizes the first letter of each sentence in paragraphs. | **Input:** `invoice approved. please process payment today. thanks.`<br>**Output:** `Invoice approved. Please process payment today. Thanks.`                                                                                                              |
| 35  | **Convert to snake_case**            | `↵`      | Replaces spaces and symbols with lowercase underscores.      | **Input:** `User Bank Account Number`<br>**Output:** `user_bank_account_number`                                                                                                                                                                            |
| 36  | **Convert to kebab-case**            | `↵`      | Replaces spaces and symbols with lowercase hyphens.          | **Input:** `User Authentication Token`<br>**Output:** `user-authentication-token`                                                                                                                                                                          |
| 37  | **Convert to camelCase**             | `↵`      | Lowercases first word and capitalizes subsequent words.      | **Input:** `Gross Taxable Invoice Amount`<br>**Output:** `grossTaxableInvoiceAmount`                                                                                                                                                                       |
| 38  | **Quote Lines (SQL IN list)**        | `↵`      | Formats multiline items into SQL `IN (...)` syntax.          | **Input:**<br>`INV-1001`<br>`INV-1002`<br>`INV-1003`<br>**Output:** `('INV-1001', 'INV-1002', 'INV-1003')`                                                                                                                                                 |
| 39  | **Join Lines into Single Paragraph** | `↵`      | Unwraps hard line breaks from copied PDFs and scans.         | **Input:**<br>`The company has completed the internal`<br>`audit for Q2 with no adverse`<br>`qualifications or compliance flags.`<br>**Output:** `The company has completed the internal audit for Q2 with no adverse qualifications or compliance flags.` |

---

### ✉️ 6. Professional Email Templates (10 Tools)

| #   | Tool Name                               | Template Content                                                                                                                                              |
| --- | --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 40  | **Email: Please Find Attached (PFA)**   | `Please find the requested file(s) attached for your review.`                                                                                                 |
| 41  | **Email: Acknowledgment & Follow-Up**   | `Acknowledged with thanks. I am reviewing this and will update you shortly.`                                                                                  |
| 42  | **Email: Meeting Availability Request** | `Could you please share your availability for a brief sync this week?`                                                                                        |
| 43  | **Email: Gentle Follow-Up / Reminder**  | `Just following up on my previous note to check if there are any updates on this.`                                                                            |
| 44  | **Email: Out of Office Notice**         | `Thank you for your email. I am currently out of the office with limited access to email. I will respond to your message as soon as possible upon my return.` |
| 45  | **Email: Formal Business Greeting**     | `Dear [Name],`                                                                                                                                                |
| 46  | **Email: Formal Sign-Off**              | `Best regards,` + signature placeholder.                                                                                                                      |
| 47  | **Email: Action Required Notice**       | `ACTION REQUIRED: Please review and confirm by EOD.`                                                                                                          |
| 48  | **Email: Handover / Delegation Note**   | `I am looping in [Name] who will assist you further with this request.`                                                                                       |
| 49  | **Email: Appreciation Note**            | `Thank you for your prompt assistance and support on this matter.`                                                                                            |

---

### 🧮 7. Math, Tax & Currency Calculators (11 Tools)

| #   | Tool Name                            | Shortcut | How it Works                                                                                    | Example                                                                                                                   |
| --- | ------------------------------------ | -------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| 50  | **Evaluate Math Expression**         | `^; c`   | Evaluates arithmetic, dimensions, markup (`+18%`), discount (`-10%`), brackets, and currencies. | **Input:** `1500x300x87` $\rightarrow$ `1500x300x87 = 39150000`<br>**Input:** `2500+18%` $\rightarrow$ `2500+18% = 2950`  |
| 51  | **Number to Words (Indian Rupees)**  | `^; w`   | Converts numbers up to **₹10,000 Crore (Level 5)** with Paise.                                  | **Input:** `1254320.50`<br>**Output:** `Rupees Twelve Lakh Fifty-Four Thousand Three Hundred Twenty and Fifty Paise Only` |
| 52  | **GST / Tax Breakdown (18%)**        | `↵`      | Calculates Base, 18% GST, and Total.                                                            | **Input:** `1000`<br>**Output:** `Base: 1000.00 \| Tax (18%): 180.00 \| Total: 1180.00`                                   |
| 53  | **Percentage Difference Calculator** | `↵`      | Computes percentage change between two numbers.                                                 | **Input:** `100 125`<br>**Output:** `100.00 -> 125.00 (+25.00%)`                                                          |
| 54  | **Generate 16-Char Secure Password** | `↵`      | Generates high-entropy random password (also copied to clipboard).                              | `aB9#mK2$xP8!vQ4@`                                                                                                        |
| 55  | **Generate UUID / GUID v4**          | `↵`      | Generates standard UUID v4 string.                                                              | `c83f9821-4f81-4235-bc32-11a5b8f2d87e`                                                                                    |
| 56  | **Word & Character Counter**         | `↵`      | Shows popup stats dialog with word, char, and line counts.                                      | `Words: 142 \| Characters: 980 \| Lines: 24`                                                                              |
| 57  | **Format Number with Commas**        | `↵`      | Formats standard international commas.                                                          | `1000000` $\rightarrow$ `1,000,000`                                                                                       |
| 58  | **Round Number to 2 Decimals**       | `↵`      | Rounds float numbers to 2 decimal places.                                                       | `1234.5678` $\rightarrow$ `1234.57`                                                                                       |
| 59  | **Sum Column of Selected Numbers**   | `↵`      | Sums all numbers in highlighted multi-line selection.                                           | **Input:** `100\n250\n450`<br>**Output:** `Sum (3 numbers): 800.00`                                                       |
| 60  | **Unix Timestamp to Readable Date**  | `↵`      | Converts epoch seconds into human date.                                                         | `1787385200` $\rightarrow$ `2026-08-22 20:46:40`                                                                          |

---

### 📁 8. File, Path & System Utilities (10 Tools)

| #   | Tool Name                               | Environment     | How it Works                                                                                             | Detailed Example                                                                                                                                  |
| --- | --------------------------------------- | --------------- | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| 61  | **Copy File Path (Forward Slashes)**    | Explorer / Text | Converts Windows backslashes to forward slashes. In editor -> **automatically pastes** converted path!   | **Explorer Selection:** `C:\Projects\Audit\Report.xlsx`<br>**Copied / Pasted:** `C:/Projects/Audit/Report.xlsx` (ready for Python, Git, Markdown) |
| 62  | **Copy File Path (Escaped Slashes)**    | Explorer / Text | Escapes all backslashes for programming and JSON. In editor -> **automatically pastes**!                 | **Input:** `C:\Users\Admin\Docs\File.txt`<br>**Copied / Pasted:** `C:\\Users\\Admin\\Docs\\File.txt` (ready for C#, Regex, JSON configs)          |
| 63  | **Prefix Selected File with Timestamp** | Explorer        | Renames selected file or folder in Explorer to `YYMMDD_name` in-place using native `DirMove`/`FileMove`. | **Selected File:** `Contract_Draft.docx`<br>**Renamed File:** `260823_Contract_Draft.docx`                                                        |
| 64  | **Google Search Selected Text**         | Any             | Launches default browser searching highlighted text or prompt query.                                     | **Selected Text:** `Section 194C TDS Limit`<br>**Action:** Opens browser to `https://www.google.com/search?q=Section+194C+TDS+Limit`              |
| 65  | **Google Translate Selected Text**      | Any             | Opens Google Translate in default browser with selected text pre-filled.                                 | **Selected Text:** `Merci pour votre aide`<br>**Action:** Opens Google Translate with source text loaded                                          |
| 66  | **Toggle Window Always-on-Top**         | System          | Pins active window (Calculator, Notepad, Browser) to float above all other apps.                         | **Scenario:** Keep Windows Calculator floating on top while entering figures into Excel.                                                          |
| 67  | **Toggle Window Transparency (75%)**    | System          | Toggles 75% opacity on active window for comparing overlaid documents.                                   | **Scenario:** Make a draft PDF semi-transparent to check alignment against underlying spreadsheet.                                                |
| 68  | **Open Today's Daily Scratchpad Notes** | System          | Automatically creates/opens timestamped daily notes file (`Scratchpad_YYYY_MM_DD.txt`) in Notepad.       | **Action:** Opens `Scratchpad_2026_08_23.txt`                                                                                                     |
| 69  | **Empty Windows Recycle Bin**           | System          | Silently purges all items from Windows Recycle Bin and confirms with a toast notification.               | **Action:** Empties Recycle Bin without prompting confirmation popups.                                                                            |
| 70  | **Quick Privacy Screen / Lock**         | System          | Instantly locks the Windows workstation (`Win+L`).                                                       | **Shortcut:** Instant workstation lock when stepping away from desk.                                                                              |

---

## 🔄 Disaster Recovery, Auto-Sync & Backup Architecture

1. **2-Second External File Watcher (`CheckExternalTaskFileChanges`):**
   * The app continuously monitors `office_productivity_tasks.csv` for external file modifications (`FileGetTime` modified timestamp).
   * If you edit, drop, or replace `office_productivity_tasks.csv` from Excel, Notepad, or cloud sync, the app **automatically detects the change within 2 seconds, reloads the tasks, and refreshes the matrix board live** with zero data loss.
2. **Weekly Automatic Snapshots (`PerformWeeklyTasksBackup`):**
   * On startup, the engine calculates the current ISO year and week (e.g. `2026_W34`).
   * If a backup snapshot for the current week does not already exist in `Backups/`, it automatically creates `Backups/tasks_backup_2026_W34.csv`.
3. **Manual Snapshot & Merge Support:**
   * Run **`Export Tasks to CSV / Backup`** from the Command Palette to take an immediate timestamped snapshot.
   * Run **`Import Tasks from External CSV`** from the Command Palette to safely merge new tasks from any CSV file without duplicating existing items.

---

## 🏛️ Modular Project Architecture

```text
📁 New folder\
├── main.ahk                          ; Master entry point, global hotkeys, Double-Shift & Double-Ctrl
├── office_productivity_tasks.csv     ; Active tasks database (Auto-synced & watched)
├── office_productivity_snippets.csv  ; User custom snippets database (CSV)
├── office_productivity_errors.log    ; Timestamped error logger
├── README_office_productivity_palette.md ; Complete documentation & manual
├── 📁 Backups\                       ; Weekly automated timestamped snapshots
└── 📁 Lib\
    ├── Core.ahk                      ; Fail-safe clipboard engine, CSV parser, Repeat Action, path resolver
    ├── PaletteGui.ahk                ; Command palette spotlight GUI & dynamic accordion
    ├── ManagerGui.ahk                ; Visual snippet manager GUI (CRUD + Import/Export)
    ├── ActionBoardGui.ahk            ; 4-Quadrant Eisenhower Matrix, custom-draw, sync & backup
    ├── Actions_Extraction.ahk        ; 7 Data extraction & date difference tools
    ├── Actions_Finance.ahk           ; 8 Indian FY, Reverse GST, CAGR & number tools
    ├── Actions_DateTime.ahk          ; 10 Date & Time tools
    ├── Actions_Text.ahk              ; 10 Text formatting & case converters
    ├── Actions_Email.ahk             ; 10 Professional email templates
    ├── Actions_Math.ahk              ; 11 Math, Indian words & tax calculators
    └── Actions_Utility.ahk           ; 10 File, path & system utilities
```
