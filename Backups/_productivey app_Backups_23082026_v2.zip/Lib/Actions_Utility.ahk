; ======================================================================================================================
; Module: Actions_Utility.ahk - 10 File, Path & System Office Utilities
; ======================================================================================================================

RegisterUtilityActions() {
    RegisterAction("Copy Clean File Path (Forward Slashes)", "📁 Utility", "Converts clipboard/selection file path to C:/Folder/File format", "path, forward, slash, url, linux, copy", (*) => ConvertClipboardPath("/"))
    RegisterAction("Copy Clean File Path (Escaped Slashes)", "📁 Utility", "Converts clipboard/selection file path to C:\\Folder\\File format", "path, escaped, double, backslash, json, code", (*) => ConvertClipboardPath("\\"))
    RegisterAction("Prefix Selected File with Timestamp", "📁 Utility", "Renames selected file in Explorer with YYMMDD_ prefix", "rename, prefix, explorer, file, timestamp", (*) => PrefixExplorerSelectedFile())
    RegisterAction("Google Search Selected Text", "📁 Utility", "Opens default browser searching selected term", "search, google, web, query, lookup", (*) => SearchWebSelection("https://www.google.com/search?q="))
    RegisterAction("Google Translate Selected Text", "📁 Utility", "Opens Google Translate for selected text", "translate, language, dict, meaning", (*) => SearchWebSelection("https://translate.google.com/?text="))
    RegisterAction("Toggle Window Always-on-Top", "📁 Utility", "Pins or unpins active window to always stay visible", "pin, top, always on top, float, window", (*) => ToggleAlwaysOnTop())
    RegisterAction("Toggle Window Transparency (75%)", "📁 Utility", "Toggles semi-transparency on active window for comparing docs", "transparent, opacity, ghost, trace, window", (*) => ToggleWindowTransparency())
    RegisterAction("Open Today's Daily Scratchpad Notes", "📁 Utility", "Opens a timestamped daily text file for notes", "scratchpad, notes, daily, journal, memo", (*) => OpenDailyScratchpad())
    RegisterAction("Empty Windows Recycle Bin", "📁 Utility", "Silently purges all items from Windows Recycle Bin", "recycle, bin, trash, clean, empty, purge", (*) => SilentEmptyRecycleBin())
    RegisterAction("Quick Privacy Screen / Lock", "📁 Utility", "Instantly locks the Windows workstation", "lock, privacy, screen, secure, workstation", (*) => DllCall("LockWorkStation"))
}

ConvertClipboardPath(slashType) {
    path := ResolveCurrentFilePath()
    
    if (path = "") {
        ShowToast("⚠️ No file or folder path found", 2000)
        return
    }

    pathClean := Trim(path, ' "`'')
    
    if (slashType = "/") {
        clean := StrReplace(pathClean, "\", "/")
    } else if (slashType = "\\") {
        clean := StrReplace(StrReplace(pathClean, "\\", "\"), "\", "\\")
    } else {
        clean := pathClean
    }

    A_Clipboard := clean
    
    ; If in an editor / document (not in File Explorer or Desktop), paste the clean path directly!
    if !WinActive("ahk_class CabinetWClass") && !WinActive("ahk_class ExploreWClass") && !WinActive("ahk_class Progman") && !WinActive("ahk_class WorkerW") {
        InsertText(clean)
    }
    
    preview := StrLen(clean) > 45 ? SubStr(clean, 1, 42) . "..." : clean
    ShowToast("✔ Copied path: " . preview, 2000)
}

PrefixExplorerSelectedFile() {
    targetPath := ResolveCurrentFilePath()
    
    if (targetPath = "" || !FileExist(targetPath)) {
        ShowToast("⚠️ Please select a file or folder in File Explorer first", 2000)
        return
    }
        
    SplitPath(targetPath, &fileName, &fileDir, &fileExt, &nameNoExt)
    prefix := FormatTime(A_Now, "yyMMdd_")
    
    if InStr(fileName, prefix) = 1 {
        ShowToast("⚠️ Already has timestamp prefix: " . fileName, 2000)
        return
    }
    
    newPath := fileDir . "\" . prefix . fileName
    try {
        if InStr(FileExist(targetPath), "D") {
            DirMove(targetPath, newPath, 0)
        } else {
            FileMove(targetPath, newPath)
        }
        ShowToast("✔ Renamed to: " . prefix . fileName, 2000)
    } catch as err {
        LogAppError("PrefixExplorerSelectedFile", err)
        ShowToast("Rename Error: " . err.Message, 2500)
    }
}

SearchWebSelection(urlPrefix) {
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("Enter search query / text:", "Web Lookup", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    Run(urlPrefix . EncodeUriComponent(Trim(sel)))
}

EncodeUriComponent(str) {
    try {
        doc := ComObject("htmlfile")
        doc.write("<meta http-equiv='X-UA-Compatible' content='IE=edge'>")
        return doc.parentWindow.encodeURIComponent(str)
    } catch {
        return str
    }
}

ToggleAlwaysOnTop() {
    hwnd := WinActive("A")
    if !hwnd
        return
    exStyle := WinGetExStyle(hwnd)
    isTop := (exStyle & 0x8)
    if isTop {
        WinSetAlwaysOnTop(0, hwnd)
        ShowToast("📌 Window Unpinned (Normal)", 1500)
    } else {
        WinSetAlwaysOnTop(1, hwnd)
        ShowToast("📌 Window Pinned (Always on Top)", 1500)
    }
}

ToggleWindowTransparency() {
    hwnd := WinActive("A")
    if !hwnd
        return
    curTrans := WinGetTransparent(hwnd)
    if (curTrans = 190) {
        WinSetTransparent(255, hwnd)
        ShowToast("Window Opacity: 100% (Solid)", 1500)
    } else {
        WinSetTransparent(190, hwnd)
        ShowToast("Window Opacity: 75% (Semi-Transparent)", 1500)
    }
}

OpenDailyScratchpad() {
    scratchPath := DataDir . "\Scratchpad_" . FormatTime(A_Now, "yyyy_MM_dd") . ".txt"
    if !FileExist(scratchPath) {
        header := "========================================================`n"
            . "Daily Scratchpad: " . FormatTime(A_Now, "dddd, MMMM d, yyyy") . "`n"
            . "========================================================`n`n"
        FileAppend(header, scratchPath, "UTF-8")
    }
    Run('notepad.exe "' . scratchPath . '"')
}

SilentEmptyRecycleBin() {
    DllCall("Shell32\SHEmptyRecycleBin", "Ptr", 0, "Ptr", 0, "UInt", 7)
    ShowToast("🗑️ Recycle Bin Emptied", 1500)
}
