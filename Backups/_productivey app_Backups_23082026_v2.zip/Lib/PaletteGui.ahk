; ======================================================================================================================
; Module: PaletteGui.ahk - Universal Command Palette (Minimal Spotlight UI & Instant 1..9 Execution)
; ======================================================================================================================

ShowCommandPalette() {
    global PaletteGui, PaletteSearch, PaletteListView, PaletteStatus, TargetWindowHwnd
    TargetWindowHwnd := WinActive("A")

    if IsObject(PaletteGui) {
        PaletteSearch.Value := ""
        FilterPaletteItems("")
        CenterGuiOnActiveMonitor(PaletteGui, 800, 56)
        PaletteGui.Show("w800 h56")
        PaletteSearch.Focus()
        return
    }

    PaletteGui := Gui("+AlwaysOnTop -Caption +Border +ToolWindow")
    PaletteGui.Title := "Command Palette"
    PaletteGui.BackColor := "0x1E1E1E"
    PaletteGui.SetFont("s11 cWhite", "Segoe UI")

    ; Search Input
    PaletteSearch := PaletteGui.Add("Edit", "x10 y10 w780 h36 Background2D2D2D cFFFFFF -E0x200")
    PaletteSearch.OnEvent("Change", (ctrl, *) => FilterPaletteItems(ctrl.Value))

    ; Results ListView (Hidden until query is entered)
    PaletteGui.SetFont("s10 cWhite", "Segoe UI")
    PaletteListView := PaletteGui.AddListView("x10 y52 w780 h300 Background252526 cFFFFFF -Multi -Hdr +LV0x14000", ["#", "Name", "Category", "Description & Usage Tip", "Shortcut"])
    PaletteListView.OnEvent("DoubleClick", (*) => PaletteExecuteSelection())
    PaletteListView.Visible := false

    ; Status / Footer
    PaletteGui.SetFont("s9 c888888", "Segoe UI")
    PaletteStatus := PaletteGui.Add("Text", "x14 y358 w770 h24", "Tap [1..9] or [Enter] to Execute | [↑↓] Navigate | [Esc] Dismiss")
    PaletteStatus.Visible := false

    CenterGuiOnActiveMonitor(PaletteGui, 800, 56)
    PaletteGui.Show("w800 h56")
    PaletteSearch.Focus()
}

FilterPaletteItems(query) {
    global BuiltInActions, CustomSnippets, PaletteListView, PaletteItems, PaletteStatus, PaletteGui
    if !IsObject(PaletteListView) || !IsObject(PaletteGui)
        return

    qTrim := Trim(query)
    qLower := StrLower(qTrim)

    ; --- Accordion Mode: Minimalist Single Bar when Empty ---
    if (qTrim = "") {
        PaletteListView.Visible := false
        PaletteStatus.Visible := false
        PaletteGui.Move(,, 800, 56)
        CenterGuiOnActiveMonitor(PaletteGui, 800, 56)
        PaletteItems := []
        return
    }

    PaletteListView.Delete()
    PaletteItems := []

    Matches(item) {
        return InStr(StrLower(item.name), qLower) 
            || InStr(StrLower(item.category), qLower) 
            || InStr(StrLower(item.description), qLower)
            || (item.HasOwnProp("keywords") && InStr(StrLower(item.keywords), qLower))
    }

    ; Match Built-In Actions
    for act in BuiltInActions {
        if Matches(act)
            PaletteItems.Push(act)
    }

    ; Match User Custom Snippets
    for snip in CustomSnippets {
        if (snip.enabled) {
            snipObj := {
                name: "Snippet: " . snip.trigger,
                category: "⚡ Snippet",
                description: "Expands: " . StrReplace(SubStr(snip.replacement, 1, 60), "`n", " ↵ "),
                keywords: snip.trigger . " snippet " . snip.replacement,
                callback: ((r) => (*) => InsertText(r))(snip.replacement),
                chord: "",
                triggerName: snip.trigger,
                isCustom: true
            }
            if Matches(snipObj)
                PaletteItems.Push(snipObj)
        }
    }

    ; Populate ListView with Guaranteed Shortcuts for EVERY Row
    for idx, item in PaletteItems {
        numBadge := (idx <= 9) ? ("[" . idx . "]") : ""
        
        ; Build explicit shortcut label
        if (item.HasOwnProp("isCustom") && item.isCustom)
            shortcutText := "::" . item.triggerName
        else if (item.chord != "")
            shortcutText := "^; " . item.chord
        else
            shortcutText := "↵"

        PaletteListView.Add("", numBadge, item.name, item.category, item.description, shortcutText)
    }

    ; Dynamically expand height based on item count
    if (PaletteItems.Length > 0) {
        rowH := 24
        calcH := Min(390, 56 + (Min(PaletteItems.Length, 12) * rowH) + 36)
        PaletteListView.Move(,, 780, calcH - 88)
        PaletteStatus.Move(, calcH - 28, 770)
        
        PaletteListView.Visible := true
        PaletteStatus.Visible := true
        PaletteGui.Move(,, 800, calcH)
        
        PaletteListView.Modify(1, "Select Focus")
    } else {
        PaletteListView.Visible := false
        PaletteStatus.Visible := true
        PaletteStatus.Move(, 56, 770)
        PaletteGui.Move(,, 800, 86)
        PaletteStatus.Text := "No matching tools found for '" . qTrim . "'"
    }

    ; Perfect Column Proportion (Total = 760px)
    try {
        PaletteListView.ModifyCol(1, "38 Center")  ; Number badge [1]..[9]
        PaletteListView.ModifyCol(2, 260)          ; Name
        PaletteListView.ModifyCol(3, 95)           ; Category
        PaletteListView.ModifyCol(4, 280)          ; Description & Usage tip
        PaletteListView.ModifyCol(5, "85 Right")   ; Guaranteed Shortcut Badge
    }

    if (PaletteItems.Length > 0 && IsObject(PaletteStatus))
        PaletteStatus.Text := "Found " . PaletteItems.Length . " tools  |  Tap [1..9] or [Enter] to Execute  |  [↑↓] Navigate  |  [Esc] Dismiss"
}

PaletteNavigate(direction) {
    global PaletteListView, PaletteItems
    if (!IsObject(PaletteListView) || !PaletteListView.Visible || PaletteItems.Length = 0)
        return
    cur := PaletteListView.GetNext()
    nextRow := cur = 0 ? 1 : (cur + direction)
    if (nextRow < 1)
        nextRow := PaletteItems.Length
    else if (nextRow > PaletteItems.Length)
        nextRow := 1
    PaletteListView.Modify(0, "-Select -Focus")
    PaletteListView.Modify(nextRow, "Select Focus Vis")
}

PaletteExecuteSelection(explicitIndex := 0) {
    global LastExecutedAction
    global PaletteListView, PaletteItems, PaletteGui, TargetWindowHwnd
    if (!IsObject(PaletteListView) || PaletteItems.Length = 0)
        return

    selectedRow := explicitIndex > 0 ? explicitIndex : PaletteListView.GetNext()
    if (!selectedRow || selectedRow > PaletteItems.Length)
        return

    item := PaletteItems[selectedRow]
    PaletteGui.Hide()

    ; Reactivate the previous target window and wait for focus
    if (TargetWindowHwnd && WinExist(TargetWindowHwnd)) {
        WinActivate(TargetWindowHwnd)
        Sleep(70)
    }

    try {
        LastExecutedAction := item
        item.callback.Call()
        ShowToast("✔ Executed: " . item.name, 1500)
    } catch as err {
        LogAppError("PaletteExecuteSelection (" . item.name . ")", err)
        ShowToast("Action Error: " . err.Message, 2500)
    }
}

CloseCommandPalette() {
    global PaletteGui, TargetWindowHwnd
    if IsObject(PaletteGui)
        PaletteGui.Hide()
    if (TargetWindowHwnd && WinExist(TargetWindowHwnd))
        WinActivate(TargetWindowHwnd)
}

IsPaletteActive() {
    global PaletteGui
    try {
        if IsObject(PaletteGui) && WinActive(PaletteGui.Hwnd)
            return true
    }
    return false
}

HasPaletteResults() {
    global PaletteGui, PaletteListView, PaletteItems
    try {
        if IsObject(PaletteGui) && WinActive(PaletteGui.Hwnd) && IsObject(PaletteListView) && PaletteListView.Visible && PaletteItems.Length > 0
            return true
    }
    return false
}
