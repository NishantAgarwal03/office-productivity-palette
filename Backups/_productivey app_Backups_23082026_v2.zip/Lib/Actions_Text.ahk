; ======================================================================================================================
; Module: Actions_Text.ahk - 10 Text Formatting & Case Transformation Tools
; ======================================================================================================================

RegisterTextActions() {
    RegisterAction("Paste Clean Plain Text", "🔤 Transform", "[Cleans Selection] Strips HTML, font styles & excess whitespace", "plain, clean, strip, paste, unformat", (*) => TransformSelectedText((txt) => Trim(txt)), "v")
    RegisterAction("Convert to UPPERCASE", "🔤 Transform", "[Needs Selection] Converts highlighted text to ALL CAPS", "upper, caps, case, uppercase", (*) => TransformSelectedText((txt) => StrUpper(txt)), "u")
    RegisterAction("Convert to lowercase", "🔤 Transform", "[Needs Selection] Converts highlighted text to all lowercase", "lower, case, lowercase", (*) => TransformSelectedText((txt) => StrLower(txt)), "l")
    RegisterAction("Convert to Title Case", "🔤 Transform", "[Needs Selection] Capitalizes The First Letter Of Every Word", "title, capitalize, case, headline", (*) => TransformSelectedText((txt) => StrTitle(txt)))
    RegisterAction("Convert to Sentence case", "🔤 Transform", "[Needs Selection] Capitalizes the first letter of each sentence", "sentence, case, grammar", (*) => TransformSelectedText((txt) => ToSentenceCase(txt)))
    RegisterAction("Convert to snake_case", "🔤 Transform", "[Needs Selection] Converts highlighted text to snake_case", "snake, case, underscore, code", (*) => TransformSelectedText((txt) => ToDelimitedCase(txt, "_")))
    RegisterAction("Convert to kebab-case", "🔤 Transform", "[Needs Selection] Converts highlighted text to kebab-case", "kebab, case, dash, slug", (*) => TransformSelectedText((txt) => ToDelimitedCase(txt, "-")))
    RegisterAction("Convert to camelCase", "🔤 Transform", "[Needs Selection] Converts highlighted text to camelCase", "camel, case, identifier, code", (*) => TransformSelectedText((txt) => ToCamelCase(txt)))
    RegisterAction("Quote Lines (SQL IN format)", "🔤 Transform", "[Needs Selection] Wraps each line in ('item1', 'item2')", "sql, quote, in, list, csv", (*) => TransformSelectedText((txt) => FormatSqlInList(txt)))
    RegisterAction("Join Lines into Single Paragraph", "🔤 Transform", "[Needs Selection] Merges PDF/web linebreaks into single paragraph", "join, unwrapper, paragraph, pdf, single line", (*) => TransformSelectedText((txt) => RegExReplace(txt, "\R+", " ")))
}

ToSentenceCase(text) {
    lower := StrLower(text)
    return RegExReplace(lower, "(?:^|[\.!\?]\s+)([a-z])", "$U1")
}

ToDelimitedCase(text, delimiter) {
    clean := RegExReplace(text, "[^\w\s-]", "")
    clean := RegExReplace(clean, "[\s_-]+", delimiter)
    return StrLower(Trim(clean, delimiter))
}

ToCamelCase(text) {
    clean := RegExReplace(text, "[^\w\s-]", " ")
    words := StrSplit(clean, [" ", "_", "-"])
    out := ""
    for idx, w in words {
        if (w = "")
            continue
        if (out = "")
            out .= StrLower(w)
        else
            out .= StrUpper(SubStr(w, 1, 1)) . StrLower(SubStr(w, 2))
    }
    return out
}

FormatSqlInList(text) {
    lines := StrSplit(text, "`n", "`r")
    items := []
    for l in lines {
        t := Trim(l)
        if (t != "")
            items.Push("'" . StrReplace(t, "'", "''") . "'")
    }
    if (items.Length = 0)
        return text
    joined := ""
    for idx, item in items {
        joined .= (idx > 1 ? ", " : "") . item
    }
    return "(" . joined . ")"
}
