; ======================================================================================================================
; Module: Actions_Math.ahk - 10 Math, Tax, Number & Conversion Tools (Self-Healing Fallbacks)
; ======================================================================================================================

RegisterMathActions() {
    RegisterAction("Evaluate Math Expression", "🧮 Math", "[Needs Selection] Computes formula (e.g. 1500 * 1.18 + 450)", "calc, math, evaluate, formula, compute", (*) => EvaluateMathSelection(), "c")
    RegisterAction("GST / Tax Breakdown (18%)", "🧮 Math", "[Needs Selection] Calculates Base + 18% Tax + Total on number", "gst, tax, 18%, vat, breakdown", (*) => CalculateTaxBreakdown(18))
    RegisterAction("Percentage Difference Calculator", "🧮 Math", "[Needs Selection] Calculates % change between two numbers", "percent, percentage, change, growth, delta", (*) => CalculatePercentageDelta())
    RegisterAction("Generate 16-Char Secure Password", "🧮 Math", "Generates & inserts random secure password (also copied to clipboard)", "password, secure, random, pass, generate", (*) => InsertText(GenerateSecurePassword(16)))
    RegisterAction("Generate UUID / GUID v4", "🧮 Math", "Generates & inserts standard UUID v4 (also copied to clipboard)", "uuid, guid, id, unique", (*) => InsertText(GenerateUUID()))
    RegisterAction("Word & Character Counter", "🧮 Math", "[Needs Selection] Shows word, character & line statistics", "count, words, characters, stats, length", (*) => ShowTextStats())
    RegisterAction("Format Number with Commas", "🧮 Math", "[Needs Selection] Formats 1000000 -> 1,000,000", "comma, format, number, digits, currency", (*) => TransformSelectedText((txt) => FormatNumberCommas(txt)))
    RegisterAction("Round Number to 2 Decimals", "🧮 Math", "[Needs Selection] Rounds float number to 2 decimal places", "round, decimal, precision, float", (*) => TransformSelectedText((txt) => RoundNumber(txt, 2)))
    RegisterAction("Sum Column of Selected Numbers", "🧮 Math", "[Needs Selection] Sums all numbers in highlighted text", "sum, total, add, column, numbers", (*) => SumSelectedNumbers())
    RegisterAction("Unix Timestamp to Readable Date", "🧮 Math", "[Needs Selection] Converts Unix epoch seconds to readable date/time", "unix, epoch, convert, time, timestamp", (*) => ConvertUnixTimestamp())
    RegisterAction("Number to Words (Indian Rupees)", "🧮 Math", "[Needs Selection] Converts amount to Indian words (e.g. Rupees Two Lakh Only)", "words, indian, lakh, crore, rupees, cheque, amount, invoice, paise", (*) => ConvertSelectedNumberToIndianWords(), "w")
}

EvaluateMathSelection() {
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("Enter a math expression to calculate (e.g. 1500*1.18+450 or 1500x300x87):", "Math Expression Evaluator", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    try {
        rawExpr := Trim(sel)
        exprClean := PreprocessMathExpression(rawExpr)
        if (exprClean = "")
            throw Error("Invalid mathematical expression")
        
        doc := ComObject("htmlfile")
        doc.write("<meta http-equiv='X-UA-Compatible' content='IE=edge'>")
        result := doc.parentWindow.eval(exprClean)
        doc.close()
        
        if IsNumber(result) {
            resFloat := Float(result)
            if (Round(resFloat, 4) = Round(resFloat, 0))
                resultStr := String(Integer(resFloat))
            else
                resultStr := RTrim(RTrim(Format("{:0.4f}", resFloat), "0"), ".")
        } else {
            resultStr := String(result)
        }
            
        displayExpr := RegExReplace(rawExpr, "\s*=\s*\??\s*$", "")
        InsertText(displayExpr . " = " . resultStr)
    } catch as err {
        LogAppError("EvaluateMathSelection", err)
        ShowToast("Math Eval Error: " . err.Message, 2500)
    }
}

PreprocessMathExpression(rawExpr) {
    expr := Trim(rawExpr)
    
    ; 1. Remove trailing '=' or '= ?' or '?'
    expr := RegExReplace(expr, "\s*=\s*\??\s*$", "")
    
    ; 2. Strip currency symbols ($, ₹, €, £, ¥)
    expr := RegExReplace(expr, "[\$₹€£¥]", "")
    
    ; 3. Remove thousand commas inside numbers (e.g. 1,500 -> 1500)
    expr := RegExReplace(expr, "(?<=\d),(?=\d{3}\b)", "")
    
    ; 4. Normalize brackets: '[' '{' -> '(', ']' '}' -> ')'
    expr := StrReplace(StrReplace(expr, "[", "("), "{", "(")
    expr := StrReplace(StrReplace(expr, "]", ")"), "}", ")")
    
    ; 5. Normalize multiplication notations: 'x', 'X', '×', '·'
    expr := RegExReplace(expr, "(?<=\d|\))\s*[xX*×·]\s*(?=\d|\()", " * ")
    
    ; 6. Normalize division notations: '÷', '\', and ratio ':'
    expr := RegExReplace(expr, "(?<=\d|\))\s*[÷\\/:]\s*(?=\d|\()", " / ")
    
    ; 7. Handle natural percentage additions/subtractions: '1500 + 18%' -> '1500 + (1500 * (18 / 100))'
    expr := RegExReplace(expr, "(\d+(?:\.\d+)?)\s*([\+\-])\s*(\d+(?:\.\d+)?)\s*%", "$1 $2 ($1 * ($3 / 100))")
    
    ; 8. Handle general percentage conversions: '500 * 20%' -> '500 * (20 / 100)'
    expr := RegExReplace(expr, "(\d+(?:\.\d+)?)\s*%", "($1 / 100)")
    
    ; 9. Handle Power / Exponentiation: '2 ^ 3' -> 'Math.pow(2, 3)'
    while RegExMatch(expr, "(\d+(?:\.\d+)?|\([^\(\)]+\))\s*(?:\^|\*\*)\s*(\d+(?:\.\d+)?|\([^\(\)]+\))", &m) {
        expr := StrReplace(expr, m[0], "Math.pow(" . m[1] . ", " . m[2] . ")", , , 1)
    }
    
    ; 10. Clean up any invalid residual characters
    exprClean := RegExReplace(expr, "[^\d\+\-\*/\.\(\)\sMath\.pow,]", "")
    return exprClean
}

CalculateTaxBreakdown(taxRatePercent) {
    sel := SafeGetSelection()
    num := RegExReplace(sel, "[^\d\.]", "")
    if (!IsNumber(num) || num <= 0) {
        ib := InputBox("Enter base amount to calculate " . taxRatePercent . "% Tax breakdown for (e.g. 1000):", "GST / Tax Calculator", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "" || !IsNumber(Trim(ib.Value)))
            return
        num := Trim(ib.Value)
    }
    base := Float(num)
    tax := base * (taxRatePercent / 100)
    total := base + tax
    out := Format("Base: {:0.2f} | Tax ({}%): {:0.2f} | Total: {:0.2f}", base, taxRatePercent, tax, total)
    InsertText(out)
}

CalculatePercentageDelta() {
    sel := SafeGetSelection()
    nums := []
    for match in StrSplit(RegExReplace(sel, "[^\d\.\s,]", " "), [" ", "`n", "`r", ","]) {
        if (Trim(match) != "" && IsNumber(match))
            nums.Push(Float(match))
    }
    if (nums.Length < 2) {
        ib := InputBox("Enter two numbers separated by space (e.g. '100 125' to calculate change from 100 to 125):", "Percentage Delta Calculator", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        for match in StrSplit(RegExReplace(ib.Value, "[^\d\.\s,]", " "), [" ", "`n", "`r", ","]) {
            if (Trim(match) != "" && IsNumber(match))
                nums.Push(Float(match))
        }
        if (nums.Length < 2)
            return
    }
    oldVal := nums[1]
    newVal := nums[2]
    if (oldVal = 0) {
        ShowToast("⚠️ Initial value cannot be 0", 2500)
        return
    }
    delta := ((newVal - oldVal) / oldVal) * 100
    out := Format("{:0.2f} -> {:0.2f} ({:+0.2f}%)", oldVal, newVal, delta)
    InsertText(out)
}

GenerateSecurePassword(length := 16) {
    chars := "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*()-_=+"
    cArr := StrSplit(chars)
    pass := ""
    Loop length {
        pass .= cArr[Random(1, cArr.Length)]
    }
    return pass
}

GenerateUUID() {
    guid := Buffer(16, 0)
    if DllCall("ole32\CoCreateGuid", "Ptr", guid.Ptr) = 0 {
        return Format("{:08X}-{:04X}-{:04X}-{:02X}{:02X}-{:02X}{:02X}{:02X}{:02X}{:02X}{:02X}",
            NumGet(guid, 0, "UInt"),
            NumGet(guid, 4, "UShort"),
            NumGet(guid, 6, "UShort"),
            NumGet(guid, 8, "UChar"), NumGet(guid, 9, "UChar"),
            NumGet(guid, 10, "UChar"), NumGet(guid, 11, "UChar"), NumGet(guid, 12, "UChar"),
            NumGet(guid, 13, "UChar"), NumGet(guid, 14, "UChar"), NumGet(guid, 15, "UChar"))
    }
    return ""
}

ShowTextStats() {
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("No text was selected. Please enter or paste text to count statistics:", "Text Statistics", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    charCount := StrLen(sel)
    charNoSpace := StrLen(RegExReplace(sel, "\s", ""))
    words := StrSplit(RegExReplace(sel, "\s+", " "), " ")
    wordCount := words.Length
    lines := StrSplit(sel, "`n", "`r")
    lineCount := lines.Length
    stats := Format("📊 Selection Stats:`n• Words: {}`n• Characters: {} (No Spaces: {})`n• Lines: {}", wordCount, charCount, charNoSpace, lineCount)
    MsgBox(stats, "Text Statistics", "Iconi")
}

FormatNumberCommas(text) {
    clean := RegExReplace(text, "[^\d\.]", "")
    if (!IsNumber(clean))
        return text
    parts := StrSplit(clean, ".")
    intPart := parts[1]
    decPart := parts.Length > 1 ? ("." . parts[2]) : ""
    formatted := RegExReplace(intPart, "\G\d+?(?=(\d{3})+$)", "$0,")
    return formatted . decPart
}

RoundNumber(text, decimals := 2) {
    clean := RegExReplace(text, "[^\d\.-]", "")
    if (IsNumber(clean))
        return String(Round(Float(clean), decimals))
    return text
}

SumSelectedNumbers() {
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("Enter numbers separated by space or newline to sum:", "Sum Numbers", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    total := 0.0
    count := 0
    for match in StrSplit(RegExReplace(sel, "[^\d\.\-\s,]", " "), [" ", "`n", "`r", ","]) {
        if (Trim(match) != "" && IsNumber(match)) {
            total += Float(match)
            count++
        }
    }
    if (count = 0) {
        ShowToast("⚠️ No valid numbers found", 2000)
        return
    }
    out := Format("Sum ({} numbers): {:0.2f}", count, total)
    InsertText(out)
}

ConvertUnixTimestamp() {
    sel := SafeGetSelection()
    num := RegExReplace(sel, "[^\d]", "")
    if (!IsNumber(num) || StrLen(num) < 9) {
        ib := InputBox("Enter Unix epoch seconds to convert (e.g. 1787385200):", "Unix Timestamp Converter", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        num := RegExReplace(ib.Value, "[^\d]", "")
        if (!IsNumber(num) || StrLen(num) < 9) {
            ShowToast("⚠️ Invalid timestamp entered", 2500)
            return
        }
    }
    epochSecs := Integer(num)
    dt := DateAdd("19700101000000", epochSecs, "seconds")
    InsertText(FormatTime(dt, "yyyy-MM-dd HH:mm:ss"))
}

ConvertSelectedNumberToIndianWords() {
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("Enter an amount/number to convert to Indian Words (e.g. 154320.50):", "Number to Words (Indian System)", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    
    words := NumberToIndianWords(sel)
    if (words = "Invalid Number") {
        ShowToast("⚠️ Invalid number entered", 2000)
        return
    }
    
    InsertText(words)
}

NumberToIndianWords(rawNum) {
    clean := RegExReplace(rawNum, "[^\d\.]", "")
    if (clean = "" || !RegExMatch(clean, "^\d+(\.\d+)?$"))
        return "Invalid Number"
    
    parts := StrSplit(clean, ".")
    intPartStr := parts[1]
    paisePart := (parts.Length > 1) ? SubStr(parts[2] . "00", 1, 2) : "00"
    
    intPart := Integer(intPartStr)
    paiseVal := Integer(paisePart)
    
    if (intPart = 0 && paiseVal = 0)
        return "Rupees Zero Only"
        
    words := ""
    if (intPart > 0)
        words := ConvertIntToIndianWords(intPart)
        
    res := ""
    if (words != "")
        res := "Rupees " . words
        
    if (paiseVal > 0) {
        paiseWords := ConvertTwoDigits(paiseVal)
        if (res != "")
            res .= " and " . paiseWords . " Paise"
        else
            res := paiseWords . " Paise"
    }
    
    return res . " Only"
}

ConvertIntToIndianWords(num) {
    if (num = 0)
        return "Zero"
        
    units := ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", 
              "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
    
    out := ""
    
    ; 1. Crores (>= 1,00,00,000)
    if (num >= 10000000) {
        croreVal := num // 10000000
        num := Mod(num, 10000000)
        out .= ConvertIntToIndianWords(croreVal) . " Crore"
    }
    
    ; 2. Lakhs (>= 1,00,000)
    if (num >= 100000) {
        lakhVal := num // 100000
        num := Mod(num, 100000)
        out .= (out != "" ? " " : "") . ConvertTwoDigits(lakhVal) . " Lakh"
    }
    
    ; 3. Thousands (>= 1,000)
    if (num >= 1000) {
        thousandVal := num // 1000
        num := Mod(num, 1000)
        out .= (out != "" ? " " : "") . ConvertTwoDigits(thousandVal) . " Thousand"
    }
    
    ; 4. Hundreds (>= 100)
    if (num >= 100) {
        hundredVal := num // 100
        num := Mod(num, 100)
        out .= (out != "" ? " " : "") . units[hundredVal] . " Hundred"
    }
    
    ; 5. Tens & Units (1 - 99)
    if (num > 0) {
        out .= (out != "" ? " " : "") . ConvertTwoDigits(num)
    }
    
    return out
}

ConvertTwoDigits(num) {
    units := ["One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", 
              "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
    tens := ["Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]
    
    if (num <= 0)
        return ""
    if (num < 20)
        return units[num]
        
    t := num // 10
    u := Mod(num, 10)
    res := tens[t - 1]
    if (u > 0)
        res .= "-" . units[u]
    return res
}
