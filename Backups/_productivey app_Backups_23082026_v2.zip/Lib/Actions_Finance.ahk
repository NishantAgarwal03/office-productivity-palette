; ======================================================================================================================
; Module: Actions_Finance.ahk - Indian Fiscal Year, Reverse GST, CAGR & Number Formatting
; ======================================================================================================================

RegisterFinanceActions() {
    RegisterAction("Indian Financial Year & Quarter", "💼 Finance", "[Needs Selection] Converts date to FY 2026–27 (Q2)", "fy, financial year, quarter, q1, q2, q3, q4, fiscal, tax", (*) => ProcessIndianFY())
    RegisterAction("Percentage Change vs Point (pp) Change", "💼 Finance", "[Needs Selection] Compares two rates (e.g. 5.0% -> 6.5% gives +1.5pp / +30%)", "percentage, point, pp, change, rate, yield, compare", (*) => ProcessPctVsPp())
    RegisterAction("CAGR Growth Calculator", "💼 Finance", "[Needs Selection] Calculates CAGR from Beg Val, End Val, Years (Natural text supported)", "cagr, growth, compound, annual, investment, returns", (*) => ProcessCAGR())
    RegisterAction("Reverse GST Calculator (18%)", "💼 Finance", "[Needs Selection] Extracts Base + 18% GST from inclusive amount or sentence", "reverse, gst, 18%, tax, base, inclusive, invoice", (*) => ProcessReverseGST(18))
    RegisterAction("Reverse GST (Custom Rate)", "💼 Finance", "[Needs Selection] Extracts Base + Tax for custom rate (e.g. GST = 12%)", "reverse, gst, rate, tax, 5%, 12%, 28%, custom", (*) => ProcessReverseGSTPrompt())
    RegisterAction("Clean Number to Raw Machine Value", "💼 Finance", "[Needs Selection] Converts '1.25 Lakh' / '2.5 Cr' / '1,25,000' -> 125000", "clean, number, machine, raw, lakh, crore, euro", (*) => TransformSelectedText((txt) => CleanToMachineNumber(txt)))
    RegisterAction("Format Number with Indian Commas", "💼 Finance", "[Needs Selection] Formats 12345678 -> 1,23,45,678 (Lakhs/Crores)", "comma, indian, lakh, crore, format, currency", (*) => TransformSelectedText((txt) => FormatIndianCommas(txt)))
    RegisterAction("Format Number with International Commas", "💼 Finance", "[Needs Selection] Formats 12345678 -> 12,345,678 (Millions/Billions)", "comma, international, million, format, standard", (*) => TransformSelectedText((txt) => FormatInternationalCommas(txt)))
}

ProcessIndianFY() {
    sel := SafeGetSelection()
    res := ResolveIndianFinancialYear(Trim(sel))
    InsertText(res)
}

ResolveIndianFinancialYear(dateStr := "") {
    if (dateStr = "")
        dt := A_Now
    else {
        ; Extract date from sentence if needed
        rawDate := dateStr
        if RegExMatch(dateStr, "i)\b(?:\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\d{1,2}[-/\s]+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[-/\s,]+\d{2,4})\b", &m)
            rawDate := m[0]
            
        parsed := ParseAnyDateToYyyyMmDd(rawDate)
        dt := (parsed != "") ? parsed . "000000" : A_Now
    }
    
    year := Integer(FormatTime(dt, "yyyy"))
    month := Integer(FormatTime(dt, "MM"))
    
    ; Indian Fiscal Year: Apr-Mar
    ; Apr(4), May(5), Jun(6) -> Q1
    ; Jul(7), Aug(8), Sep(9) -> Q2
    ; Oct(10), Nov(11), Dec(12) -> Q3
    ; Jan(1), Feb(2), Mar(3) -> Q4
    if (month >= 4) {
        fyStart := year
        fyEnd := SubStr(String(year + 1), 3, 2)
        qtr := (month <= 6) ? "Q1" : (month <= 9) ? "Q2" : "Q3"
    } else {
        fyStart := year - 1
        fyEnd := SubStr(String(year), 3, 2)
        qtr := "Q4"
    }
    
    return Format("FY {}-{} ({})", fyStart, fyEnd, qtr)
}

ProcessPctVsPp() {
    sel := SafeGetSelection()
    nums := []
    for match in StrSplit(RegExReplace(sel, "[^\d\.\-\s,]", " "), [" ", "`n", "`r", ","]) {
        if (Trim(match) != "" && IsNumber(match))
            nums.Push(Float(match))
    }
    if (nums.Length < 2) {
        ib := InputBox("Enter initial rate and final rate (e.g. '5.0 6.5' for 5% to 6.5%):", "Percentage vs Percentage-Point Change", "w480 h160")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        for match in StrSplit(RegExReplace(ib.Value, "[^\d\.\-\s,]", " "), [" ", "`n", "`r", ","]) {
            if (Trim(match) != "" && IsNumber(match))
                nums.Push(Float(match))
        }
        if (nums.Length < 2)
            return
    }
    report := CalculatePercentageVsPercentagePoints(nums[1], nums[2])
    MsgBox(report, "Percentage Change vs Percentage-Point Change", "Iconi")
}

CalculatePercentageVsPercentagePoints(val1, val2) {
    v1 := Float(val1)
    v2 := Float(val2)
    
    ppDiff := v2 - v1
    if (v1 = 0)
        relPct := 0.0
    else
        relPct := ((v2 - v1) / v1) * 100
        
    return Format("{:0.2f}% -> {:0.2f}%:`n• Percentage-Point (pp) Change: {:+0.2f} pp`n• Relative Percentage Change: {:+0.2f}%", v1, v2, ppDiff, relPct)
}

ProcessCAGR() {
    sel := SafeGetSelection()
    begVal := 0.0, endVal := 0.0, numYears := 0.0
    
    ; Check natural sentence format: "Investment increased from ₹10,00,000 to ₹20,00,000 over 5 years."
    if (Trim(sel) != "") {
        clean := RegExReplace(sel, "[,`r`n]", " ")
        if RegExMatch(clean, "i)(?:from\s+)?(?:₹|Rs\.?|\$)?\s*([\d\.]+)\s*(?:lakh|lakhs|cr|crore|crores|k|m)?\s*(?:to|-|->)\s*(?:₹|Rs\.?|\$)?\s*([\d\.]+)\s*(?:lakh|lakhs|cr|crore|crores|k|m)?\s*(?:over|in|for)\s*([\d\.]+)\s*(?:years?|yrs?)", &m) {
            begVal := CleanToMachineNumber(m[1])
            endVal := CleanToMachineNumber(m[2])
            numYears := Float(m[3])
        }
    }
    
    if (begVal <= 0 || endVal <= 0 || numYears <= 0) {
        nums := []
        for match in StrSplit(RegExReplace(sel, "[^\d\.\s,]", " "), [" ", "`n", "`r", ","]) {
            if (Trim(match) != "" && IsNumber(match))
                nums.Push(Float(match))
        }
        if (nums.Length >= 3) {
            begVal := nums[1]
            endVal := nums[2]
            numYears := nums[3]
        }
    }
    
    if (begVal <= 0 || endVal <= 0 || numYears <= 0) {
        ib := InputBox("Enter Beginning Value, Ending Value, and Number of Years (e.g. 1000000 2000000 5 or 'from 10 Lakh to 20 Lakh over 5 years'):", "CAGR Growth Calculator", "w520 h160")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
            
        clean := RegExReplace(ib.Value, "[,`r`n]", " ")
        if RegExMatch(clean, "i)(?:from\s+)?(?:₹|Rs\.?|\$)?\s*([\d\.]+)\s*(?:to|-|->)\s*(?:₹|Rs\.?|\$)?\s*([\d\.]+)\s*(?:over|in|for)\s*([\d\.]+)", &m) {
            begVal := Float(m[1])
            endVal := Float(m[2])
            numYears := Float(m[3])
        } else {
            nums := []
            for match in StrSplit(RegExReplace(ib.Value, "[^\d\.\s,]", " "), [" ", "`n", "`r", ","]) {
                if (Trim(match) != "" && IsNumber(match))
                    nums.Push(Float(match))
            }
            if (nums.Length >= 3) {
                begVal := nums[1]
                endVal := nums[2]
                numYears := nums[3]
            }
        }
        if (begVal <= 0 || endVal <= 0 || numYears <= 0)
            return
    }
    
    report := CalculateCAGR(begVal, endVal, numYears)
    MsgBox(report, "CAGR Growth Calculator", "Iconi")
}

CalculateCAGR(begVal, endVal, numYears) {
    b := Float(begVal)
    e := Float(endVal)
    y := Float(numYears)
    
    if (b <= 0 || e <= 0 || y <= 0)
        return "Invalid parameters for CAGR"
        
    cagr := ((e / b) ** (1 / y) - 1) * 100
    absReturn := ((e - b) / b) * 100
    multiple := e / b
    
    res := Format("Investment Growth (CAGR):`n• Beginning Value: ₹{}`n• Ending Value: ₹{}`n• Investment Period: {:0.1f} Years`n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`n➜ Compound Annual Growth Rate (CAGR): {:0.2f}%`n• Absolute Return: {:+0.2f}% (₹{})`n• Growth Multiple: {:0.2f}x", 
                  FormatIndianCommas(b), FormatIndianCommas(e), y, cagr, absReturn, FormatIndianCommas(e - b), multiple)
    return res
}

ProcessReverseGST(defaultRate := 18) {
    sel := SafeGetSelection()
    extractedAmt := 0.0
    extractedRate := defaultRate
    
    if (Trim(sel) != "") {
        clean := RegExReplace(sel, "[,`r`n]", " ")
        ; Check if rate is specified in text (e.g. 18% GST, GST = 12%, etc.)
        if RegExMatch(clean, "i)(?:GST\s*=?\s*|including\s+)(\d+(?:\.\d+)?)\s*%", &mRate) {
            extractedRate := Float(mRate[1])
        }
        
        ; Extract amount
        if RegExMatch(clean, "i)(?:₹|Rs\.?|\$|is\s+|amount\s*=\s*)([\d\.]+)", &mAmt) {
            extractedAmt := Float(mAmt[1])
        } else {
            rawNum := RegExReplace(clean, "[^\d\.]", "")
            if (IsNumber(rawNum) && Float(rawNum) > 0)
                extractedAmt := Float(rawNum)
        }
    }
    
    if (extractedAmt <= 0) {
        ib := InputBox("Enter total GST-inclusive amount (e.g. 118000 or 'invoice total including 18% GST is ₹1,18,000'):", "Reverse GST Calculator (" . extractedRate . "%)", "w500 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
            
        clean := RegExReplace(ib.Value, "[,`r`n]", " ")
        if RegExMatch(clean, "i)(?:GST\s*=?\s*|including\s+)(\d+(?:\.\d+)?)\s*%", &mRate) {
            extractedRate := Float(mRate[1])
        }
        if RegExMatch(clean, "i)(?:₹|Rs\.?|\$|is\s+|amount\s*=\s*)([\d\.]+)", &mAmt) {
            extractedAmt := Float(mAmt[1])
        } else {
            rawNum := RegExReplace(clean, "[^\d\.]", "")
            if (IsNumber(rawNum) && Float(rawNum) > 0)
                extractedAmt := Float(rawNum)
        }
        if (extractedAmt <= 0)
            return
    }
    
    report := CalculateReverseGST(extractedAmt, extractedRate)
    InsertText(report)
}

ProcessReverseGSTPrompt() {
    sel := SafeGetSelection()
    detectedRate := 18.0
    detectedAmt := 0.0
    
    if (Trim(sel) != "") {
        clean := RegExReplace(sel, "[,`r`n]", " ")
        if RegExMatch(clean, "i)(?:GST\s*=?\s*|including\s+)(\d+(?:\.\d+)?)\s*%", &mRate) {
            detectedRate := Float(mRate[1])
        }
        if RegExMatch(clean, "i)(?:₹|Rs\.?|\$|is\s+|amount\s*=\s*)([\d\.]+)", &mAmt) {
            detectedAmt := Float(mAmt[1])
        }
    }
    
    if (detectedAmt > 0) {
        report := CalculateReverseGST(detectedAmt, detectedRate)
        InsertText(report)
        return
    }
    
    ibRate := InputBox("Enter GST Rate percentage (e.g. 5, 12, 18, 28):", "Select GST Rate", "w420 h150", String(detectedRate))
    if (ibRate.Result != "OK" || Trim(ibRate.Value) = "" || !IsNumber(Trim(ibRate.Value)))
        return
    rate := Float(Trim(ibRate.Value))
    ProcessReverseGST(rate)
}

CalculateReverseGST(totalAmount, gstRate := 18) {
    tot := Float(totalAmount)
    if (tot <= 0)
        return "Invalid amount"
        
    rate := Float(gstRate)
    base := tot / (1 + (rate / 100))
    tax := tot - base
    halfTax := tax / 2
    
    res := Format("Total (Incl. {}% GST): ₹{}`n• Taxable Base: ₹{}`n• Total GST ({}%): ₹{} (CGST: ₹{} | SGST: ₹{})", 
                  rate, FormatIndianCommas(tot), FormatIndianCommas(base), rate, FormatIndianCommas(tax), FormatIndianCommas(halfTax), FormatIndianCommas(halfTax))
    return res
}

CleanToMachineNumber(rawText) {
    txt := Trim(rawText)
    
    ; Check for Indian crore / lakh words
    if RegExMatch(txt, "i)([\d\.]+)\s*(?:cr|crore|crores)", &m) {
        val := Float(m[1]) * 10000000
        return String(Integer(val))
    }
    if RegExMatch(txt, "i)([\d\.]+)\s*(?:l|lakh|lakhs|lac|lacs)", &m) {
        val := Float(m[1]) * 100000
        return String(Integer(val))
    }
    if RegExMatch(txt, "i)([\d\.]+)\s*(?:k|thousand|thousands)", &m) {
        val := Float(m[1]) * 1000
        return String(Integer(val))
    }
    
    ; Check European format (1.250,50 -> 1250.50)
    if RegExMatch(txt, "^\d{1,3}(?:\.\d{3})+,\d{2}$") {
        txt := StrReplace(txt, ".", "")
        txt := StrReplace(txt, ",", ".")
        return txt
    }
    
    ; Standard strip currency and commas
    clean := RegExReplace(txt, "[^\d\.-]", "")
    return clean
}

FormatIndianCommas(num) {
    clean := RegExReplace(String(num), "[^\d\.]", "")
    if (clean = "")
        return "0.00"
        
    parts := StrSplit(clean, ".")
    intStr := parts[1]
    decStr := (parts.Length > 1) ? ("." . SubStr(parts[2] . "00", 1, 2)) : ".00"
    
    len := StrLen(intStr)
    if (len <= 3)
        return intStr . decStr
        
    last3 := SubStr(intStr, len - 2)
    rest := SubStr(intStr, 1, len - 3)
    
    formattedRest := RegExReplace(rest, "\G\d+?(?=(\d{2})+$)", "$0,")
    return formattedRest . "," . last3 . decStr
}

FormatInternationalCommas(num) {
    clean := RegExReplace(String(num), "[^\d\.]", "")
    if (clean = "")
        return "0.00"
    parts := StrSplit(clean, ".")
    intStr := parts[1]
    decStr := (parts.Length > 1) ? ("." . SubStr(parts[2] . "00", 1, 2)) : ".00"
    formatted := RegExReplace(intStr, "\G\d+?(?=(\d{3})+$)", "$0,")
    return formatted . decStr
}
