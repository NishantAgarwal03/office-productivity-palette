; ======================================================================================================================
; Module: Core.ahk - Core Engine, Fail-Safe Clipboard, CSV Storage, & Dynamic Hotstrings
; ======================================================================================================================

RegisterAction(name, category, description, keywords, callback, chord := "") {
    global BuiltInActions
    BuiltInActions.Push({
        name: name,
        category: category,
        description: description,
        keywords: keywords,
        callback: callback,
        chord: chord,
        isCustom: false
    })
}

; --- Fail-Safe Clipboard & Text Insertion Engine ---
InsertText(text) {
    if (text = "")
        return
    try {
        A_Clipboard := text
        ClipWait(0.4)
        Sleep(50)
        SendInput("^{vk56}") ; Ctrl + V
    } catch as err {
        LogAppError("InsertText", err)
        SendText(text)
    }
}

TransformSelectedText(transformerFunc) {
    selText := SafeGetSelection()
    if (Trim(selText) = "") {
        ; Self-healing fallback prompt if user didn't select text beforehand
        ib := InputBox("No text was highlighted. Please enter or paste the text to transform:", AppTitle . " - Text Input", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        selText := ib.Value
    }
    try {
        newText := transformerFunc.Call(selText)
        InsertText(newText)
    } catch as err {
        LogAppError("TransformSelectedText", err)
        ShowToast("Transformation Error: " . err.Message, 2500)
    }
}

SafeGetSelection() {
    clipBackup := ClipboardAll()
    A_Clipboard := ""
    SendInput("^{vk43}") ; Ctrl + C
    if !ClipWait(0.3) {
        A_Clipboard := clipBackup
        return ""
    }
    sel := A_Clipboard
    A_Clipboard := clipBackup
    return sel
}

; --- Instant Snippet Capture ---
CaptureSelectedTextAsSnippet() {
    global CustomSnippets
    selectedText := SafeGetSelection()
    if (Trim(selectedText) = "") {
        ib := InputBox("No text was selected. Please enter or paste the snippet text to save:", "Create New Snippet", "w460 h160")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        selectedText := ib.Value
    }
    inputBox := InputBox("Enter a short trigger keyword for this snippet (e.g. 'supmail'):`n`nSnippet Preview:`n" . SubStr(selectedText, 1, 100) . "...", "Save Snippet As Hotstring", "w420 h220")
    if (inputBox.Result != "OK" || Trim(inputBox.Value) = "")
        return

    trigger := Trim(inputBox.Value)
    for snip in CustomSnippets {
        if (StrLower(snip.trigger) = StrLower(trigger)) {
            MsgBox("Trigger '" . trigger . "' already exists. Please choose a unique name.", AppTitle, "Icon!")
            return
        }
    }
    CustomSnippets.Push({trigger: trigger, replacement: selectedText, enabled: true})
    SaveCustomSnippets()
    RegisterDynamicHotstrings()
    ShowToast("✅ Snippet '" . trigger . "' saved & active!", 2500)
}

; --- Leader Key Chords ---
ActivateLeaderKey() {
    global LeaderActive, BuiltInActions
    LeaderActive := true
    ToolTip("⚡ [Leader Mode] Press: d=Date | t=Time | u=Upper | l=Lower | c=Calc | v=PasteRaw | ?=Help")
    
    ih := InputHook("L1 T1.5 C")
    ih.Start()
    ih.Wait()
    
    ToolTip()
    LeaderActive := false

    if (ih.EndReason != "EndKey" && ih.EndReason != "Max")
        return

    key := StrLower(ih.Input)
    if (key = "" || key = "`e")
        return

    if (key = "?") {
        ShowCommandPalette()
        return
    }

    for act in BuiltInActions {
        if (act.chord != "" && StrLower(act.chord) = key) {
            try {
                act.callback.Call()
                ShowToast("✔ Executed: " . act.name, 1500)
            } catch as err {
                LogAppError("LeaderChord (" . act.name . ")", err)
            }
            return
        }
    }

    ShowToast("Unknown Leader Key: '" . key . "' (Press '?' for Palette)", 2000)
}

; --- CSV Persistent Storage ---
LoadCustomSnippets() {
    global CustomSnippets, SnippetsFile
    CustomSnippets := []

    if !FileExist(SnippetsFile) {
        CustomSnippets.Push({trigger: "myemail", replacement: "john.doe@example.com", enabled: true})
        CustomSnippets.Push({trigger: "myphone", replacement: "+1 (555) 123-4567", enabled: true})
        CustomSnippets.Push({trigger: "myaddr", replacement: "123 Main Street`nAnytown, ST 12345`nUSA", enabled: true})
        SaveCustomSnippets()
        return
    }

    try {
        content := FileRead(SnippetsFile, "UTF-8")
        rows := ParseFullCSV(content)

        for rIdx, row in rows {
            if (rIdx = 1 && row.Length >= 1 && StrLower(Trim(row[1])) = "trigger")
                continue
            if (row.Length >= 3) {
                t := Trim(row[1])
                if (t = "")
                    continue
                r := StrReplace(row[2], "\n", "`n")
                e := (StrLower(Trim(row[3])) = "true" || Trim(row[3]) = "1")
                CustomSnippets.Push({trigger: t, replacement: r, enabled: e})
            }
        }
    } catch as err {
        LogAppError("LoadCustomSnippets", err)
    }
}

SaveCustomSnippets() {
    global CustomSnippets, SnippetsFile
    local content := "trigger,replacement,enabled`n"
    local tempFile := SnippetsFile . ".tmp"
    local fileObj := ""
    local writeOk := false

    for snip in CustomSnippets {
        local trigEsc := '"' . StrReplace(snip.trigger, '"', '""') . '"'
        local repEsc := '"' . StrReplace(StrReplace(snip.replacement, '"', '""'), "`n", "\n") . '"'
        local enStr := snip.enabled ? "true" : "false"
        content .= trigEsc . "," . repEsc . "," . enStr . "`n"
    }

    try {
        fileObj := FileOpen(tempFile, "w", "UTF-8")
        if !IsObject(fileObj)
            throw Error("Cannot create temporary snippets file")
        fileObj.Write(content)
        writeOk := true
    } catch as err {
        LogAppError("SaveCustomSnippets", err)
    } finally {
        if IsObject(fileObj)
            fileObj.Close()
    }

    if writeOk {
        if FileExist(SnippetsFile)
            FileDelete(SnippetsFile)
        FileMove(tempFile, SnippetsFile)
    }
}

ParseFullCSV(csvContent) {
    local rows := []
    local curRow := []
    local curField := ""
    local inQuotes := false
    local chars := StrSplit(csvContent)
    local i := 1
    local len := chars.Length

    while i <= len {
        local ch := chars[i]
        if (ch = '"') {
            if (inQuotes && i < len && chars[i + 1] = '"') {
                curField .= '"'
                i++
            } else {
                inQuotes := !inQuotes
            }
        } else if (ch = ',' && !inQuotes) {
            curRow.Push(curField)
            curField := ""
        } else if ((ch = "`n" || ch = "`r") && !inQuotes) {
            if (ch = "`r" && i < len && chars[i + 1] = "`n")
                i++
            curRow.Push(curField)
            if (curRow.Length > 0 && (curRow.Length > 1 || curRow[1] != ""))
                rows.Push(curRow)
            curRow := []
            curField := ""
        } else {
            curField .= ch
        }
        i++
    }
    if (curField != "" || curRow.Length > 0) {
        curRow.Push(curField)
        if (curRow.Length > 1 || curRow[1] != "")
            rows.Push(curRow)
    }
    return rows
}

; --- Dynamic Hotstrings ---
RegisterDynamicHotstrings() {
    global RegisteredTriggers, CustomSnippets
    Hotstring("Reset")

    for trig in RegisteredTriggers {
        try {
            Hotstring(":X C0:" . trig, , 0)
        }
    }
    RegisteredTriggers.Clear()

    for snip in CustomSnippets {
        if (snip.enabled && snip.trigger != "") {
            try {
                Hotstring(":X C0:" . snip.trigger, HotstringCallback.Bind(snip.replacement), 1)
                RegisteredTriggers[snip.trigger] := true
            } catch as err {
                LogAppError("RegisterDynamicHotstrings (" . snip.trigger . ")", err)
            }
        }
    }
}

HotstringCallback(replacement, *) {
    InsertText(replacement . A_EndChar)
}

; --- Core UI & Logger Utilities ---
ShowProductivityHelp() {
    help := "
    (
Office Productivity Command Palette & Snippet Suite
====================================================

PRIMARY ACCESS SHORTCUTS:
- Double-Tap Shift : Universal Command Palette (Search all 50+ tools).
- Ctrl + Space     : Fallback shortcut for Command Palette.
- Ctrl + ;         : Leader Key mode (tap Ctrl+; then tap d, t, u, c, v).
- Ctrl + Shift + H : Highlight & Save instant snippet capture.
- Win + Esc        : Snippet & Text Replacement Manager GUI.

50 BUILT-IN TOOL CATEGORIES:
- Date & Time   : ISO Dates, timestamps, tomorrow, work-week ranges.
- Transform     : Plain text paste, UPPER, lower, Title, snake_case.
- Email         : PFA, Out of office, meeting requests, sign-offs.
- Math & Data   : In-line formula eval, GST 18%, percentage delta, UUID.
- Utilities     : Path converters, Always-on-Top, web search, scratchpad.
    )"
    MsgBox(help, AppTitle . " - User Guide", "Iconi")
}

ShowToast(msg, durationMs := 2000) {
    ToolTip("⚡ " . msg)
    SetTimer(() => ToolTip(), -durationMs)
}

CenterGuiOnActiveMonitor(guiObj, width, height) {
    try {
        CoordMode("Mouse", "Screen")
        MouseGetPos(&mX, &mY)
        monCount := MonitorGetCount()
        targetMon := 1
        Loop monCount {
            MonitorGetWorkArea(A_Index, &mL, &mT, &mR, &mB)
            if (mX >= mL && mX <= mR && mY >= mT && mY <= mB) {
                targetMon := A_Index
                break
            }
        }
        MonitorGetWorkArea(targetMon, &mL, &mT, &mR, &mB)
        posX := mL + ((mR - mL - width) // 2)
        posY := mT + ((mB - mT - height) // 2)
        guiObj.Move(posX, posY, width, height)
    }
}

LogAppError(context, errObj) {
    try {
        timestamp := FormatTime(A_Now, "yyyy-MM-dd HH:mm:ss")
        entry := Format("[{}] [{}] Error in {}: {} (Line {})`n", timestamp, AppVersion, context, errObj.Message, errObj.Line)
        FileAppend(entry, ErrorLogFile, "UTF-8")
    }
}

; --- Repeat Last Action Engine ---
RepeatLastAction() {
    global LastExecutedAction
    if (!IsObject(LastExecutedAction) || !LastExecutedAction.HasOwnProp("callback")) {
        ShowToast("⚠️ No previous action to repeat", 2000)
        return
    }
    try {
        LastExecutedAction.callback.Call()
        ShowToast("🔁 Repeated: " . LastExecutedAction.name, 1500)
    } catch as err {
        LogAppError("RepeatLastAction (" . LastExecutedAction.name . ")", err)
        ShowToast("Repeat Error: " . err.Message, 2500)
    }
}

ResolveCurrentFilePath() {
    global TargetWindowHwnd
    hwnd := TargetWindowHwnd ? TargetWindowHwnd : WinActive("A")
    
    if (hwnd) {
        try {
            wClass := WinGetClass(hwnd)
            if (wClass = "CabinetWClass" || wClass = "ExploreWClass") {
                shellApp := ComObject("Shell.Application")
                for window in shellApp.Windows {
                    try {
                        if (window && window.HWND = hwnd) {
                            sel := window.Document.SelectedItems
                            if (sel && sel.Count > 0) {
                                res := ""
                                for item in sel
                                    res .= (A_Index > 1 ? "`n" : "") . item.Path
                                if (res != "")
                                    return res
                            }
                            if IsObject(window.Document.Folder) {
                                dirPath := window.Document.Folder.Self.Path
                                if (dirPath != "")
                                    return dirPath
                            }
                        }
                    }
                }
            }
        }
    }
    
    try {
        shellApp := ComObject("Shell.Application")
        for window in shellApp.Windows {
            try {
                if (window && window.Visible && IsObject(window.Document.Folder)) {
                    sel := window.Document.SelectedItems
                    if (sel && sel.Count > 0) {
                        res := ""
                        for item in sel
                            res .= (A_Index > 1 ? "`n" : "") . item.Path
                        if (res != "")
                            return res
                    }
                    dirPath := window.Document.Folder.Self.Path
                    if (dirPath != "")
                        return dirPath
                }
            }
        }
    }
    
    if (hwnd) {
        try {
            wClass := WinGetClass(hwnd)
            if (wClass = "Progman" || wClass = "WorkerW")
                return A_Desktop
        }
    }
    
    sel := SafeGetSelection()
    if (Trim(sel) != "" && (InStr(sel, "\") || InStr(sel, "/")))
        return Trim(sel)
        
    if (Trim(A_Clipboard) != "" && (InStr(A_Clipboard, "\") || InStr(A_Clipboard, "/")))
        return Trim(A_Clipboard)
        
    return ""
}
