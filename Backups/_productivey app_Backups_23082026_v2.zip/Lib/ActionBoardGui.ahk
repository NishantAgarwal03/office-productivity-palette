; ======================================================================================================================
; Module: ActionBoardGui.ahk - 4-Quadrant Spatial Eisenhower Matrix Board (Win + T)
; ======================================================================================================================

global ActionTasksFile       := DataDir . "\office_productivity_tasks.csv"
global ActionTasks           := []
global ActionBoardGui        := ""
global InputTaskBox          := ""
global LV_Q1                 := ""
global LV_Q2                 := ""
global LV_Q3                 := ""
global LV_Q4                 := ""
global LastActiveLV          := ""
global PreviewTaskTextCtrl   := ""
global PreviewMetaCtrl       := ""
global ActionStatusText      := ""

global ClassifierGui         := ""
global PrioritizerMiniGui    := ""
global LastClassifiedTime    := 0
global LastPrioritizedTime   := 0

RegisterActionBoardActions() {
    RegisterAction("Open Action Board (Eisenhower Grid)", "📋 Tasks", "Opens the 4-Quadrant visual matrix board", "task, board, matrix, eisenhower, grid, 4 quadrant, todo", (*) => ToggleActionBoard())
    RegisterAction("Capture Selected Text as Task", "📋 Tasks", "Saves highlighted text as a pending action item", "task, add, new, commitment, capture, todo", (*) => CaptureSelectedTextAsTask())
    RegisterAction("Export Tasks to CSV / Backup", "📋 Tasks", "Creates a timestamped backup snapshot of tasks.csv", "export, backup, tasks, csv, save, snapshot", (*) => ExportTasksManually())
    RegisterAction("Import Tasks from External CSV", "📋 Tasks", "Imports and merges tasks from any external CSV file", "import, load, tasks, csv, merge, restore", (*) => ImportTasksPrompt())
}

; --- Initialization & Timers ---
global LastTaskFileModTime := 0

InitActionBoardEngine() {
    global LastTaskFileModTime, ActionTasksFile
    LoadActionTasks()
    if FileExist(ActionTasksFile)
        LastTaskFileModTime := FileGetTime(ActionTasksFile, "M")
    
    ; Perform silent weekly backup on startup
    PerformWeeklyTasksBackup()
    
    ; Register WM_NOTIFY for per-item custom color drawing
    OnMessage(0x004E, MatrixOnWmNotify)
    
    ; Register WM_LBUTTONDOWN for frameless window dragging
    OnMessage(0x0201, ActionBoardOnLButtonDown)
    
    ; Auto-Import / Auto-Reload File Watcher (checks every 2 seconds if file was updated externally)
    SetTimer(CheckExternalTaskFileChanges, 2000)
    
    SetTimer(CheckPendingCommitmentClassifier, 6000)
    SetTimer(CheckPendingPrioritizerMini, 30000)
    SetTimer(CheckHighPriorityNudges, 60000)
}

; --- CSV Storage ---
LoadActionTasks() {
    global ActionTasks, ActionTasksFile
    ActionTasks := []
    
    if !FileExist(ActionTasksFile) {
        ActionTasks.Push({id: 1, task: "Review and approve GST audit report by Friday 5 PM", created: FormatTime(A_Now, "yyyy-MM-dd HH:mm"), commitmentType: "Deadline", priority: "Q1", done: false})
        ActionTasks.Push({id: 2, task: "Send updated contract draft to client", created: FormatTime(A_Now, "yyyy-MM-dd HH:mm"), commitmentType: "Promise", priority: "Q2", done: false})
        ActionTasks.Push({id: 3, task: "Send Zoom invite for vendor sync", created: FormatTime(A_Now, "yyyy-MM-dd HH:mm"), commitmentType: "Quick", priority: "Q3", done: false})
        ActionTasks.Push({id: 4, task: "Read new direct tax circular", created: FormatTime(A_Now, "yyyy-MM-dd HH:mm"), commitmentType: "Review", priority: "Q4", done: false})
        SaveActionTasks()
        return
    }
    
    try {
        content := FileRead(ActionTasksFile, "UTF-8")
        rows := ParseFullCSV(content)
        for rIdx, row in rows {
            if (rIdx = 1 && row.Length >= 1 && StrLower(Trim(row[1])) = "id")
                continue
            if (row.Length >= 6) {
                idVal := Integer(Trim(row[1]))
                t := Trim(row[2])
                if (t = "")
                    continue
                c := row[3]
                ct := row[4]
                p := NormalizePriority(Trim(row[5]))
                d := (StrLower(Trim(row[6])) = "true" || Trim(row[6]) = "1")
                ActionTasks.Push({id: idVal, task: t, created: c, commitmentType: ct, priority: p, done: d})
            }
        }
    } catch as err {
        LogAppError("LoadActionTasks", err)
    }
}

NormalizePriority(pStr) {
    if InStr(pStr, "1")
        return "Q1"
    if InStr(pStr, "2")
        return "Q2"
    if InStr(pStr, "3")
        return "Q3"
    return "Q4"
}

SaveActionTasks() {
    global ActionTasks, ActionTasksFile
    local content := "id,task,created,commitmentType,priority,done`n"
    local tempFile := ActionTasksFile . ".tmp"
    local fileObj := ""
    local writeOk := false

    for t in ActionTasks {
        local idEsc := t.id
        local taskEsc := '"' . StrReplace(t.task, '"', '""') . '"'
        local cEsc := '"' . t.created . '"'
        local ctEsc := '"' . StrReplace(t.commitmentType, '"', '""') . '"'
        local pEsc := '"' . StrReplace(t.priority, '"', '""') . '"'
        local doneStr := t.done ? "true" : "false"
        content .= idEsc . "," . taskEsc . "," . cEsc . "," . ctEsc . "," . pEsc . "," . doneStr . "`n"
    }

    try {
        fileObj := FileOpen(tempFile, "w", "UTF-8")
        if !IsObject(fileObj)
            throw Error("Cannot create temporary tasks file")
        fileObj.Write(content)
        writeOk := true
    } catch as err {
        LogAppError("SaveActionTasks", err)
    } finally {
        if IsObject(fileObj)
            fileObj.Close()
    }

    if writeOk {
        if FileExist(ActionTasksFile)
            FileDelete(ActionTasksFile)
        FileMove(tempFile, ActionTasksFile)
    }
}

CaptureSelectedTextAsTask() {
    global ActionTasks
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("Enter task description:", "Quick Add Task", "w420 h130")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    
    AddNewTaskDirect(Trim(sel), "Q4")
}

AddNewTaskDirect(taskText, defaultQuadrant := "Q4") {
    global ActionTasks
    if (Trim(taskText) = "")
        return
        
    nowStr := FormatTime(A_Now, "yyyy-MM-dd HH:mm")
    newId := ActionTasks.Length > 0 ? ActionTasks[ActionTasks.Length].id + 1 : 1
    
    ActionTasks.Push({
        id: newId,
        task: taskText,
        created: nowStr,
        commitmentType: "Unassigned",
        priority: defaultQuadrant,
        done: false
    })
    SaveActionTasks()
    
    preview := StrLen(taskText) > 35 ? SubStr(taskText, 1, 32) . "..." : taskText
    ShowToast("📌 Added to " . defaultQuadrant . ": " . preview, 2000)
    RefreshMatrixBoard()
}

; ======================================================================================================================
; 4-QUADRANT SPATIAL EISENHOWER BOARD GUI (Win + T)
; ======================================================================================================================

ToggleActionBoard() {
    global ActionBoardGui
    if IsObject(ActionBoardGui) {
        if WinActive(ActionBoardGui.Hwnd) {
            ActionBoardGui.Hide()
            return
        }
        ActionBoardGui.Show()
        RefreshMatrixBoard()
        return
    }
    CreateActionBoardGui()
}

CreateActionBoardGui() {
    global ActionBoardGui, InputTaskBox, LV_Q1, LV_Q2, LV_Q3, LV_Q4, PreviewTaskTextCtrl, PreviewMetaCtrl, ActionStatusText, LastActiveLV
    
    ActionBoardGui := Gui("+AlwaysOnTop -Caption +Border +Owner")
    ActionBoardGui.BackColor := "121212"
    ActionBoardGui.SetFont("s10 cFFFFFF", "Segoe UI")
    
    ActionBoardGui.OnEvent("Escape", (g) => g.Hide())
    
    ; Top Direct Add / Search Input Bar with Native Placeholder
    InputTaskBox := ActionBoardGui.Add("Edit", "x15 y10 w820 h28 cFFFFFF Background222222 -E0x200 vTaskInput", "")
    DllCall("user32\SendMessage", "ptr", InputTaskBox.Hwnd, "uint", 0x1501, "ptr", 1, "wstr", "➕ Type a new task and press Enter (or search to filter)...")
    
    ; Row 1: Q1 (Top-Left, Coral Red #FF5252) & Q2 (Top-Right, Sky Blue #40C4FF)
    ActionBoardGui.SetFont("s9 bold cFF5252", "Segoe UI")
    ActionBoardGui.Add("Text", "x15 y48 w390", "🔥 Q1: DO FIRST (Urgent && Important)")
    
    ActionBoardGui.SetFont("s9 bold c40C4FF", "Segoe UI")
    ActionBoardGui.Add("Text", "x445 y48 w390", "📅 Q2: SCHEDULE (Important, Not Urgent)")
    
    ActionBoardGui.SetFont("s9 cFFFFFF", "Segoe UI")
    LV_Q1 := ActionBoardGui.AddListView("x15 y68 w390 h150 Background221212 cFFFFFF -Hdr -Multi +Report -Theme +LV0x10000", ["Display", "ID"])
    LV_Q2 := ActionBoardGui.AddListView("x445 y68 w390 h150 Background0E1B24 cFFFFFF -Hdr -Multi +Report -Theme +LV0x10000", ["Display", "ID"])
    
    ; Row 2: Q3 (Bottom-Left, Golden Amber #FFD54F) & Q4 (Bottom-Right, Mint Green #69F0AE)
    ActionBoardGui.SetFont("s9 bold cFFD54F", "Segoe UI")
    ActionBoardGui.Add("Text", "x15 y226 w390", "⚡ Q3: QUICK WIN (<5m / Delegate)")
    
    ActionBoardGui.SetFont("s9 bold c69F0AE", "Segoe UI")
    ActionBoardGui.Add("Text", "x445 y226 w390", "⏳ Q4: BACKLOG / LATER (Low Priority)")
    
    ActionBoardGui.SetFont("s9 cFFFFFF", "Segoe UI")
    LV_Q3 := ActionBoardGui.AddListView("x15 y246 w390 h150 Background1F1A0B cFFFFFF -Hdr -Multi +Report -Theme +LV0x10000", ["Display", "ID"])
    LV_Q4 := ActionBoardGui.AddListView("x445 y246 w390 h150 Background0E1E14 cFFFFFF -Hdr -Multi +Report -Theme +LV0x10000", ["Display", "ID"])
    
    ; Apply Dark Theme to ListViews to eliminate white borders
    try {
        DllCall("uxtheme\SetWindowTheme", "ptr", LV_Q1.Hwnd, "str", "DarkMode_Explorer", "str", "Explorer")
        DllCall("uxtheme\SetWindowTheme", "ptr", LV_Q2.Hwnd, "str", "DarkMode_Explorer", "str", "Explorer")
        DllCall("uxtheme\SetWindowTheme", "ptr", LV_Q3.Hwnd, "str", "DarkMode_Explorer", "str", "Explorer")
        DllCall("uxtheme\SetWindowTheme", "ptr", LV_Q4.Hwnd, "str", "DarkMode_Explorer", "str", "Explorer")
    }
    
    ; Track focus & selection preview
    LV_Q1.OnEvent("ItemSelect", (ctrl, item, selected) => OnTaskItemSelect(LV_Q1, item, selected))
    LV_Q2.OnEvent("ItemSelect", (ctrl, item, selected) => OnTaskItemSelect(LV_Q2, item, selected))
    LV_Q3.OnEvent("ItemSelect", (ctrl, item, selected) => OnTaskItemSelect(LV_Q3, item, selected))
    LV_Q4.OnEvent("ItemSelect", (ctrl, item, selected) => OnTaskItemSelect(LV_Q4, item, selected))
    
    LV_Q1.OnEvent("DoubleClick", (*) => MatrixViewOrToggle(LV_Q1))
    LV_Q2.OnEvent("DoubleClick", (*) => MatrixViewOrToggle(LV_Q2))
    LV_Q3.OnEvent("DoubleClick", (*) => MatrixViewOrToggle(LV_Q3))
    LV_Q4.OnEvent("DoubleClick", (*) => MatrixViewOrToggle(LV_Q4))
    
    ; Line 1: Continuous Single-Line Task Text Ribbon (IN CRISP WHITE)
    ActionBoardGui.SetFont("s9 cFFFFFF", "Segoe UI")
    PreviewTaskTextCtrl := ActionBoardGui.Add("Edit", "x15 y402 w820 h26 ReadOnly Background181818 cFFFFFF -E0x200 -Wrap", "Select any task above to view its continuous text...")
    
    ; Line 2: Fixed-Position Status & Metadata Ribbon (IN CRISP WHITE)
    ActionBoardGui.SetFont("s9 bold cFFFFFF", "Segoe UI")
    PreviewMetaCtrl := ActionBoardGui.Add("Text", "x15 y432 w820 h18 cFFFFFF", "[Status: Ready  |  Quadrant: -  |  Created: -]")
    
    ; Line 3: Bottom Shortcut Bar (IN LIGHT GRAY / WHITE)
    ActionBoardGui.SetFont("s8 cAAAAAA", "Segoe UI")
    ActionStatusText := ActionBoardGui.Add("Text", "x15 y456 w820 h18", "[Enter] Add Task  •  [1-4] Move Quadrant  •  [Space] Toggle Done  •  [V] Full Editor  •  [Del] Delete  •  [Esc] Close  •  (Drag window anywhere)")
    
    CenterGuiOnActiveMonitor(ActionBoardGui, 850, 485)
    ActionBoardGui.Show("w850 h485")
    RefreshMatrixBoard()
}

; ======================================================================================================================
; WIN32 NM_CUSTOMDRAW HANDLER: PER-ITEM COLORS (Unassigned = White, Assigned = Quadrant Header Color)
; ======================================================================================================================

MatrixOnWmNotify(wParam, lParam, msg, hwnd) {
    global LV_Q1, LV_Q2, LV_Q3, LV_Q4
    static NM_CUSTOMDRAW       := -12
    static CDDS_PREPAINT       := 0x00000001
    static CDDS_ITEMPREPAINT   := 0x00010001
    static CDRF_NOTIFYITEMDRAW := 0x00000020
    static CDRF_NEWFONT        := 0x00000002
    
    code := NumGet(lParam, A_PtrSize * 2, "int")
    if (code != NM_CUSTOMDRAW)
        return
        
    hwndFrom := NumGet(lParam, 0, "ptr")
    
    ; Determine which quadrant listview sent this notification
    targetLV := 0
    assignedBgrColor := 0xFFFFFF
    
    if (IsObject(LV_Q1) && hwndFrom = LV_Q1.Hwnd) {
        targetLV := LV_Q1
        assignedBgrColor := 0x5252FF ; Coral Red (RGB 0xFF5252 -> BGR 0x5252FF)
    } else if (IsObject(LV_Q2) && hwndFrom = LV_Q2.Hwnd) {
        targetLV := LV_Q2
        assignedBgrColor := 0xFFC440 ; Sky Blue (RGB 0x40C4FF -> BGR 0xFFC440)
    } else if (IsObject(LV_Q3) && hwndFrom = LV_Q3.Hwnd) {
        targetLV := LV_Q3
        assignedBgrColor := 0x4FD5FF ; Golden Amber (RGB 0xFFD54F -> BGR 0x4FD5FF)
    } else if (IsObject(LV_Q4) && hwndFrom = LV_Q4.Hwnd) {
        targetLV := LV_Q4
        assignedBgrColor := 0xAEF069 ; Mint Green (RGB 0x69F0AE -> BGR 0xAEF069)
    } else {
        return
    }
    
    dwDrawStage := NumGet(lParam, A_PtrSize * 3, "uint")
    
    if (dwDrawStage = CDDS_PREPAINT)
        return CDRF_NOTIFYITEMDRAW
        
    if (dwDrawStage = CDDS_ITEMPREPAINT) {
        rowIdx := NumGet(lParam, 56, "uptr") + 1
        itemText := targetLV.GetText(rowIdx, 1)
        
        if InStr(itemText, "[NEW]") {
            ; UNASSIGNED TASK: Crisp Bright White (BGR 0xFFFFFF)
            NumPut("uint", 0xFFFFFF, lParam, 80)
        } else {
            ; ASSIGNED TASK: Exact Quadrant Header Color
            NumPut("uint", assignedBgrColor, lParam, 80)
        }
        return CDRF_NEWFONT
    }
}

OnTaskItemSelect(lvCtrl, item, selected) {
    global LastActiveLV, PreviewTaskTextCtrl, PreviewMetaCtrl, ActionTasks
    LastActiveLV := lvCtrl
    if (!selected || item <= 0)
        return
        
    taskIdStr := lvCtrl.GetText(item, 2)
    if (taskIdStr = "")
        return
    taskId := Integer(taskIdStr)
    
    for t in ActionTasks {
        if (t.id = taskId) {
            statusStr := t.done ? "✔ COMPLETED" : "⏳ PENDING"
            singleLineText := RegExReplace(t.task, "[\r\n]+", " ")
            singleLineText := RegExReplace(singleLineText, "[ \t]+", " ")
            
            if IsObject(PreviewTaskTextCtrl) {
                PreviewTaskTextCtrl.Value := singleLineText
            }
            if IsObject(PreviewMetaCtrl) {
                prioName := (t.priority = "Q1") ? "🔥 Q1 (Do First)" : (t.priority = "Q2") ? "📅 Q2 (Schedule)" : (t.priority = "Q3") ? "⚡ Q3 (Quick Win)" : "⏳ Q4 (Backlog)"
                typeStr := (t.commitmentType = "Unassigned" || t.commitmentType = "" || t.commitmentType = "Task") ? "Unassigned" : t.commitmentType
                PreviewMetaCtrl.Text := "[Status: " . statusStr . "  |  Quadrant: " . prioName . "  |  Type: " . typeStr . "  |  Created: " . t.created . "]"
            }
            break
        }
    }
}

RefreshMatrixBoard(filter := "") {
    global LV_Q1, LV_Q2, LV_Q3, LV_Q4, ActionTasks, ActionStatusText, PreviewTaskTextCtrl, PreviewMetaCtrl
    if !IsObject(LV_Q1) || !IsObject(LV_Q2) || !IsObject(LV_Q3) || !IsObject(LV_Q4)
        return
        
    LV_Q1.Delete()
    LV_Q2.Delete()
    LV_Q3.Delete()
    LV_Q4.Delete()
    
    filterLower := StrLower(Trim(filter))
    counts := Map("Q1", 0, "Q2", 0, "Q3", 0, "Q4", 0)
    
    for t in ActionTasks {
        if (filterLower != "" && !InStr(StrLower(t.task), filterLower))
            continue
            
        statusStr := t.done ? "[✔] " : "[ ] "
        prio := t.priority
        if !counts.Has(prio)
            prio := "Q4"
            
        if !t.done
            counts[prio]++
            
        isUnassigned := (t.commitmentType = "Unassigned" || t.commitmentType = "" || t.commitmentType = "Task")
        
        displayTask := statusStr
        if isUnassigned
            displayTask .= "[NEW] "
        displayTask .= t.task
            
        switch prio {
            case "Q1": LV_Q1.Add("", displayTask, String(t.id))
            case "Q2": LV_Q2.Add("", displayTask, String(t.id))
            case "Q3": LV_Q3.Add("", displayTask, String(t.id))
            default:   LV_Q4.Add("", displayTask, String(t.id))
        }
    }
    
    try {
        LV_Q1.ModifyCol(1, 365), LV_Q1.ModifyCol(2, 0)
        LV_Q2.ModifyCol(1, 365), LV_Q2.ModifyCol(2, 0)
        LV_Q3.ModifyCol(1, 365), LV_Q3.ModifyCol(2, 0)
        LV_Q4.ModifyCol(1, 365), LV_Q4.ModifyCol(2, 0)
    }
    
    if IsObject(ActionStatusText) {
        ActionStatusText.Text := "Active Tasks: Q1 (" . counts["Q1"] . ") | Q2 (" . counts["Q2"] . ") | Q3 (" . counts["Q3"] . ") | Q4 (" . counts["Q4"] . ")  •  [1-4] Move  •  [Space] Done  •  [V] Full View  •  [Del] Delete  •  [Esc] Close"
    }
}

MatrixMoveSelectedTask(targetQuadrant) {
    global LastActiveLV, LV_Q1, LV_Q2, LV_Q3, LV_Q4, ActionTasks
    targetLV := IsObject(LastActiveLV) ? LastActiveLV : (LV_Q1.GetNext() ? LV_Q1 : LV_Q2.GetNext() ? LV_Q2 : LV_Q3.GetNext() ? LV_Q3 : LV_Q4)
    if !IsObject(targetLV)
        return
        
    selRow := targetLV.GetNext()
    if (!selRow)
        return
        
    taskIdStr := targetLV.GetText(selRow, 2)
    if (taskIdStr = "")
        return
    taskId := Integer(taskIdStr)
    
    for t in ActionTasks {
        if (t.id = taskId) {
            t.priority := targetQuadrant
            if (t.commitmentType = "Unassigned" || t.commitmentType = "Task")
                t.commitmentType := "Assigned"
            break
        }
    }
    SaveActionTasks()
    RefreshMatrixBoard()
}

MatrixToggleDone(targetLV := "") {
    global LastActiveLV, LV_Q1, LV_Q2, LV_Q3, LV_Q4, ActionTasks
    if !IsObject(targetLV)
        targetLV := IsObject(LastActiveLV) ? LastActiveLV : (LV_Q1.GetNext() ? LV_Q1 : LV_Q2.GetNext() ? LV_Q2 : LV_Q3.GetNext() ? LV_Q3 : LV_Q4)
    if !IsObject(targetLV)
        return
        
    selRow := targetLV.GetNext()
    if (!selRow)
        return
        
    taskIdStr := targetLV.GetText(selRow, 2)
    if (taskIdStr = "")
        return
    taskId := Integer(taskIdStr)
    
    for t in ActionTasks {
        if (t.id = taskId) {
            t.done := !t.done
            break
        }
    }
    SaveActionTasks()
    RefreshMatrixBoard()
}

MatrixViewOrToggle(targetLV) {
    selRow := targetLV.GetNext()
    if (!selRow)
        return
    taskIdStr := targetLV.GetText(selRow, 2)
    if (taskIdStr != "")
        ShowFullTaskViewModal(Integer(taskIdStr))
}

ShowFullTaskViewModal(taskId := 0) {
    global ActionTasks, LastActiveLV, LV_Q1, LV_Q2, LV_Q3, LV_Q4
    if (taskId = 0) {
        targetLV := IsObject(LastActiveLV) ? LastActiveLV : (LV_Q1.GetNext() ? LV_Q1 : LV_Q2.GetNext() ? LV_Q2 : LV_Q3.GetNext() ? LV_Q3 : LV_Q4)
        if IsObject(targetLV) && (selRow := targetLV.GetNext()) {
            tStr := targetLV.GetText(selRow, 2)
            if (tStr != "")
                taskId := Integer(tStr)
        }
    }
    if (taskId = 0)
        return
        
    targetTask := ""
    for t in ActionTasks {
        if (t.id = taskId) {
            targetTask := t
            break
        }
    }
    if !IsObject(targetTask)
        return
        
    viewGui := Gui("+AlwaysOnTop -MaximizeBox -MinimizeBox")
    viewGui.Title := "Task Detail View & Editor"
    viewGui.SetFont("s10", "Segoe UI")
    
    viewGui.Add("Text", "x15 y12 w450 cGray", "Full Task / Commitment Description:")
    editCtrl := viewGui.Add("Edit", "x15 y32 w450 h120 vFullDesc", targetTask.task)
    
    statusStr := targetTask.done ? "✔ Completed" : "⏳ Pending"
    viewGui.SetFont("s9", "Segoe UI")
    viewGui.Add("Text", "x15 y160 w450 cGray", "Quadrant: " . targetTask.priority . "  |  Status: " . statusStr . "  |  Created: " . targetTask.created)
    
    btnSave := viewGui.AddButton("x15 y190 w120 h30 Default", "💾 Save Changes")
    btnSave.OnEvent("Click", (*) => SaveTaskEdit(viewGui, targetTask, editCtrl.Value))
    
    btnToggle := viewGui.AddButton("x145 y190 w140 h30", targetTask.done ? "Mark as Pending" : "✔ Mark Completed")
    btnToggle.OnEvent("Click", (*) => ToggleTaskInModal(viewGui, targetTask))
    
    btnClose := viewGui.AddButton("x365 y190 w100 h30", "Close")
    btnClose.OnEvent("Click", (*) => viewGui.Destroy())
    
    CenterGuiOnActiveMonitor(viewGui, 480, 235)
    viewGui.Show("w480 h235")
}

SaveTaskEdit(guiObj, taskObj, newText) {
    if (Trim(newText) != "") {
        taskObj.task := Trim(newText)
        SaveActionTasks()
        RefreshMatrixBoard()
        ShowToast("✔ Task updated", 1000)
    }
    guiObj.Destroy()
}

ToggleTaskInModal(guiObj, taskObj) {
    taskObj.done := !taskObj.done
    SaveActionTasks()
    RefreshMatrixBoard()
    guiObj.Destroy()
    ShowToast(taskObj.done ? "✔ Marked completed" : "⏳ Marked pending", 1000)
}

MatrixDeleteSelectedTask(targetLV := "") {
    global LastActiveLV, LV_Q1, LV_Q2, LV_Q3, LV_Q4, ActionTasks
    if !IsObject(targetLV)
        targetLV := IsObject(LastActiveLV) ? LastActiveLV : (LV_Q1.GetNext() ? LV_Q1 : LV_Q2.GetNext() ? LV_Q2 : LV_Q3.GetNext() ? LV_Q3 : LV_Q4)
    if !IsObject(targetLV)
        return
        
    selRow := targetLV.GetNext()
    if (!selRow)
        return
        
    taskIdStr := targetLV.GetText(selRow, 2)
    if (taskIdStr = "")
        return
    taskId := Integer(taskIdStr)
    
    for idx, t in ActionTasks {
        if (t.id = taskId) {
            ActionTasks.RemoveAt(idx)
            break
        }
    }
    SaveActionTasks()
    RefreshMatrixBoard()
}

HandleMatrixEnterKey() {
    global InputTaskBox, ActionBoardGui
    if !IsObject(InputTaskBox)
        return
        
    txt := Trim(InputTaskBox.Value)
    if (txt != "") {
        AddNewTaskDirect(txt, "Q4")
        InputTaskBox.Value := ""
    }
}

; Window Dragging Handler for Frameless Action Board
ActionBoardOnLButtonDown(wParam, lParam, msg, hwnd) {
    global ActionBoardGui
    if IsObject(ActionBoardGui) && (hwnd = ActionBoardGui.Hwnd) {
        PostMessage(0xA1, 2,,, ActionBoardGui.Hwnd) ; WM_NCLBUTTONDOWN (HTCAPTION)
    }
}

; ======================================================================================================================
; STEP 2 & 3: ULTRA-MINIMAL FLOATING PILLS FOR NUDGES
; ======================================================================================================================

; ======================================================================================================================
; STEP 2 & 3: UNIFIED TOP-LEFT FLOATING PILLS FOR NUDGES & CLASSIFIERS
; ======================================================================================================================

; ======================================================================================================================
; STEP 2 & 3: ICON-FIRST, HIGH-SPEED (<1s) FLOATING PILLS FOR NUDGES & CLASSIFIERS
; ======================================================================================================================

; ======================================================================================================================
; STEP 2 & 3: INTUITIVE, DISTINCT DARK-THEMED MINI-PILLS FOR CLASSIFIER & PRIORITIZER
; ======================================================================================================================

; ======================================================================================================================
; STEP 2 & 3: COLOR-CODED, DYNAMIC-SIZED MINI-PILLS FOR CLASSIFIER & PRIORITIZER
; ======================================================================================================================

; ======================================================================================================================
; STEP 2 & 3: PROMINENT TASK-FIRST MINI-PILLS (80% TASK, 15% ICONS, 5% LABELS)
; ======================================================================================================================

; ======================================================================================================================
; STEP 2 & 3: PROMINENT TASK-FIRST MINI-PILLS (16PT TASK TYPOGRAPHY, 10PT CHIPS)
; ======================================================================================================================

CheckPendingCommitmentClassifier() {
    global ActionTasks, LastClassifiedTime, ClassifierGui
    if IsObject(ClassifierGui)
        return
    if (A_TickCount - LastClassifiedTime < 600000)
        return
    for t in ActionTasks {
        ; Condition 1: Must be unclassified commitment
        if (!t.done && (t.commitmentType = "" || t.commitmentType = "Unassigned" || t.commitmentType = "Task")) {
            ShowCommitmentClassifierMiniUI(t)
            break
        }
    }
}

ShowCommitmentClassifierMiniUI(taskObj) {
    global ClassifierGui, LastClassifiedTime
    if IsObject(ClassifierGui)
        ClassifierGui.Destroy()
        
    ClassifierGui := Gui("+AlwaysOnTop -Caption +ToolWindow +Border")
    ClassifierGui.BackColor := "181818" ; Clean Obsidian Dark
    ClassifierGui.OnEvent("Escape", (g) => DismissClassifier(g))
    
    ; Flatten task to continuous line up to 300 chars
    cleanTask := RegExReplace(taskObj.task, "[\r\n]+", " ")
    cleanTask := RegExReplace(cleanTask, "[ \t]+", " ")
    prev := StrLen(cleanTask) > 300 ? SubStr(cleanTask, 1, 297) . "..." : cleanTask
    
    ; Dynamic Height Calculation (for 16pt font)
    isSingleLine := (StrLen(prev) <= 32)
    textH := isSingleLine ? 30 : 58
    btnY1 := isSingleLine ? 46 : 74
    btnY2 := isSingleLine ? 76 : 104
    guiH  := isSingleLine ? 114 : 142
    
    ; Task text (80% Prominence): Prominent 16pt Typography
    ClassifierGui.SetFont("s16 bold cFFFFFF", "Segoe UI")
    ClassifierGui.Add("Text", "x14 y10 w442 h" . textH, "📋 " . prev)
    
    ; 6 Action Chips (10pt bold text)
    ClassifierGui.SetFont("s10 bold", "Segoe UI Emoji")
    
    ; Row 1
    c1 := ClassifierGui.Add("Text", "x14 y" . btnY1 . " w142 h26 Center Background182E38 c64D2FF +Border 0x200", "📦 1 Deliver")
    c1.OnEvent("Click", (*) => FastSetType(ClassifierGui, taskObj, "Deliverable"))
    
    c2 := ClassifierGui.Add("Text", "x164 y" . btnY1 . " w142 h26 Center Background1E2238 c82AAFF +Border 0x200", "🤝 2 Promise")
    c2.OnEvent("Click", (*) => FastSetType(ClassifierGui, taskObj, "Promise"))
    
    c3 := ClassifierGui.Add("Text", "x314 y" . btnY1 . " w142 h26 Center Background381818 cFF757F +Border 0x200", "⏰ 3 Deadline")
    c3.OnEvent("Click", (*) => FastSetType(ClassifierGui, taskObj, "Deadline"))
    
    ; Row 2
    c4 := ClassifierGui.Add("Text", "x14 y" . btnY2 . " w142 h26 Center Background302414 cFFC777 +Border 0x200", "🔄 4 Follow")
    c4.OnEvent("Click", (*) => FastSetType(ClassifierGui, taskObj, "Follow-Up"))
    
    c5 := ClassifierGui.Add("Text", "x164 y" . btnY2 . " w142 h26 Center Background281838 cC099FF +Border 0x200", "🔍 5 Review")
    c5.OnEvent("Click", (*) => FastSetType(ClassifierGui, taskObj, "Review"))
    
    c6 := ClassifierGui.Add("Text", "x314 y" . btnY2 . " w142 h26 Center Background143022 c73DACA +Border 0x200", "⚡ 6 Quick")
    c6.OnEvent("Click", (*) => FastSetType(ClassifierGui, taskObj, "Quick"))
    
    ; Position on TOP-LEFT of Primary Screen (w470 h114/142)
    MonitorGetWorkArea(1, &mL, &mT, &mR, &mB)
    posX := mL + 25
    posY := mT + 25
    ClassifierGui.Show("x" . posX . " y" . posY . " w470 h" . guiH . " NoActivate")
    
    ; Auto-dismiss on 10s inactivity
    SetTimer(() => DismissClassifier(ClassifierGui), -10000)
}

FastSetType(guiObj, taskObj, typeName) {
    global LastClassifiedTime
    taskObj.commitmentType := typeName
    SaveActionTasks()
    LastClassifiedTime := A_TickCount
    if IsObject(guiObj)
        guiObj.Destroy()
    RefreshMatrixBoard()
    ShowToast("✔ " . typeName, 1000)
}

DismissClassifier(guiObj) {
    global LastClassifiedTime
    LastClassifiedTime := A_TickCount
    if IsObject(guiObj) {
        try guiObj.Destroy()
    }
}

CheckPendingPrioritizerMini() {
    global ActionTasks, LastPrioritizedTime, PrioritizerMiniGui
    if IsObject(PrioritizerMiniGui)
        return
    if (A_TickCount - LastPrioritizedTime < 3600000)
        return
    for t in ActionTasks {
        ; Condition 2: MUST already be classified (not Unassigned/Task), but sitting in Q4 backlog!
        if (!t.done && t.priority = "Q4" && t.commitmentType != "" && t.commitmentType != "Unassigned" && t.commitmentType != "Task") {
            ShowPrioritizerMiniUI(t)
            break
        }
    }
}

ShowPrioritizerMiniUI(taskObj) {
    global PrioritizerMiniGui, LastPrioritizedTime
    if IsObject(PrioritizerMiniGui)
        PrioritizerMiniGui.Destroy()
        
    PrioritizerMiniGui := Gui("+AlwaysOnTop -Caption +ToolWindow +Border")
    PrioritizerMiniGui.BackColor := "181818" ; Clean Obsidian Dark
    PrioritizerMiniGui.OnEvent("Escape", (g) => DismissPrioritizerMini(g))
    
    ; Flatten task to continuous line up to 300 chars
    cleanTask := RegExReplace(taskObj.task, "[\r\n]+", " ")
    cleanTask := RegExReplace(cleanTask, "[ \t]+", " ")
    prev := StrLen(cleanTask) > 280 ? SubStr(cleanTask, 1, 277) . "..." : cleanTask
    
    ; Dynamic Height Calculation (for 16pt font)
    isSingleLine := (StrLen(prev) <= 28)
    textH := isSingleLine ? 30 : 58
    btnY1 := isSingleLine ? 46 : 74
    btnY2 := isSingleLine ? 76 : 104
    guiH  := isSingleLine ? 114 : 142
    
    ; Task text (80% Prominence): Prominent 16pt Typography with badge
    typeBadge := "[" . taskObj.commitmentType . "]"
    PrioritizerMiniGui.SetFont("s16 bold cFFFFFF", "Segoe UI")
    PrioritizerMiniGui.Add("Text", "x14 y10 w442 h" . textH, "🎯 " . typeBadge . " " . prev)
    
    ; 4 Quadrant Chips (10pt bold text)
    PrioritizerMiniGui.SetFont("s10 bold", "Segoe UI Emoji")
    
    ; Row 1: Q1 (Coral Red) & Q2 (Sky Blue)
    c1 := PrioritizerMiniGui.Add("Text", "x14 y" . btnY1 . " w216 h26 Center Background321414 cFF5252 +Border 0x200", "🔥 1 DO FIRST")
    c1.OnEvent("Click", (*) => FastSetPrioMini(PrioritizerMiniGui, taskObj, "Q1"))
    
    c2 := PrioritizerMiniGui.Add("Text", "x240 y" . btnY1 . " w216 h26 Center Background102232 c40C4FF +Border 0x200", "📅 2 SCHEDULE")
    c2.OnEvent("Click", (*) => FastSetPrioMini(PrioritizerMiniGui, taskObj, "Q2"))
    
    ; Row 2: Q3 (Golden Amber) & Q4 (Mint Green)
    c3 := PrioritizerMiniGui.Add("Text", "x14 y" . btnY2 . " w216 h26 Center Background2E2210 cFFD54F +Border 0x200", "⚡ 3 QUICK WIN")
    c3.OnEvent("Click", (*) => FastSetPrioMini(PrioritizerMiniGui, taskObj, "Q3"))
    
    c4 := PrioritizerMiniGui.Add("Text", "x240 y" . btnY2 . " w216 h26 Center Background122818 c69F0AE +Border 0x200", "⏳ 4 BACKLOG")
    c4.OnEvent("Click", (*) => FastSetPrioMini(PrioritizerMiniGui, taskObj, "Q4"))
    
    ; Position on TOP-LEFT of Primary Screen
    MonitorGetWorkArea(1, &mL, &mT, &mR, &mB)
    posX := mL + 25
    posY := mT + 25
    PrioritizerMiniGui.Show("x" . posX . " y" . posY . " w470 h" . guiH . " NoActivate")
    
    ; Auto-dismiss on 10s inactivity
    SetTimer(() => DismissPrioritizerMini(PrioritizerMiniGui), -10000)
}

FastSetPrioMini(guiObj, taskObj, prioName) {
    global LastPrioritizedTime
    taskObj.priority := prioName
    SaveActionTasks()
    LastPrioritizedTime := A_TickCount
    if IsObject(guiObj)
        guiObj.Destroy()
    RefreshMatrixBoard()
    ShowToast("✔ Moved to " . prioName, 1000)
}

DismissPrioritizerMini(guiObj) {
    global LastPrioritizedTime
    LastPrioritizedTime := A_TickCount
    if IsObject(guiObj) {
        try guiObj.Destroy()
    }
}

; ======================================================================================================================
; UI 6: HIGH-PRIORITY Q1 URGENT NUDGE (~3 INCHES FROM CURSOR, CLAMPED TO SCREEN)
; ======================================================================================================================

global NudgeHudGui := ""

CheckHighPriorityNudges() {
    global ActionTasks, NudgeHudGui
    highTasks := []
    for t in ActionTasks {
        if (!t.done && t.priority = "Q1")
            highTasks.Push(t)
    }
    
    if (highTasks.Length = 0)
        return
        
    if IsObject(NudgeHudGui)
        NudgeHudGui.Destroy()
        
    NudgeHudGui := Gui("+AlwaysOnTop -Caption +ToolWindow +Border")
    NudgeHudGui.BackColor := "181818" ; User Requested: #181818 Dark Theme
    
    ; Header Line: 8pt Bold Coral Red
    NudgeHudGui.SetFont("s8 bold cFF5252", "Segoe UI")
    NudgeHudGui.Add("Text", "x14 y8 w430 h16", "🔥 Q1 URGENT (" . highTasks.Length . " Active)")
    
    ; Task Item Lines (Top 2 items): 12pt Semi-bold Crisp White
    NudgeHudGui.SetFont("s12 bold cFFFFFF", "Segoe UI")
    item1Text := "1. " . (StrLen(highTasks[1].task) > 42 ? SubStr(highTasks[1].task, 1, 39) . "..." : highTasks[1].task)
    NudgeHudGui.Add("Text", "x14 y26 w430 h24", item1Text)
    
    hudWidth := 460
    hudHeight := 58
    if (highTasks.Length >= 2) {
        item2Text := "2. " . (StrLen(highTasks[2].task) > 42 ? SubStr(highTasks[2].task, 1, 39) . "..." : highTasks[2].task)
        NudgeHudGui.Add("Text", "x14 y52 w430 h24", item2Text)
        hudHeight := 84
    }
    
    ; Get Cursor Position (Screen coordinates)
    CoordMode("Mouse", "Screen")
    MouseGetPos(&curX, &curY)
    
    ; Offset by ~3 inches (~260 pixels)
    offsetDist := 260
    posX := curX + offsetDist
    posY := curY - 40
    
    ; Get Monitor Work Area and Clamp to Screen Boundaries
    monIdx := 1
    try {
        monCount := MonitorGetCount()
        loop monCount {
            MonitorGet(A_Index, &mLeft, &mTop, &mRight, &mBottom)
            if (curX >= mLeft && curX <= mRight && curY >= mTop && curY <= mBottom) {
                monIdx := A_Index
                break
            }
        }
    }
    MonitorGetWorkArea(monIdx, &mL, &mT, &mR, &mB)
    
    ; If right offset overflows monitor, flip to left of cursor
    if (posX + hudWidth > mR - 20) {
        posX := curX - offsetDist - hudWidth
    }
    ; If still overflows left boundary, clamp
    if (posX < mL + 20) {
        posX := mL + 20
    }
    
    ; Clamp vertical boundary
    if (posY + hudHeight > mB - 20) {
        posY := mB - hudHeight - 20
    }
    if (posY < mT + 20) {
        posY := mT + 20
    }
    
    NudgeHudGui.Show("x" . posX . " y" . posY . " w" . hudWidth . " h" . hudHeight . " NoActivate")
    
    ; Auto-dismiss in 2.5 seconds
    SetTimer(() => DismissNudgeHud(NudgeHudGui), -2500)
}

DismissNudgeHud(guiObj) {
    if IsObject(guiObj) {
        try guiObj.Destroy()
    }
}

IsActionBoardActive() {
    global ActionBoardGui
    return IsObject(ActionBoardGui) && WinActive(ActionBoardGui.Hwnd)
}

IsInputTaskBoxFocused() {
    global InputTaskBox, ActionBoardGui
    return IsObject(ActionBoardGui) && WinActive(ActionBoardGui.Hwnd) && IsObject(InputTaskBox) && (InputTaskBox.Hwnd = ControlGetFocus(ActionBoardGui.Hwnd))
}

; ======================================================================================================================
; AUTOMATIC FILE WATCHER, WEEKLY BACKUP & IMPORT/EXPORT ENGINE
; ======================================================================================================================

CheckExternalTaskFileChanges() {
    global LastTaskFileModTime, ActionTasksFile
    if !FileExist(ActionTasksFile)
        return
        
    try {
        currentModTime := FileGetTime(ActionTasksFile, "M")
        if (LastTaskFileModTime != 0 && currentModTime != LastTaskFileModTime) {
            LastTaskFileModTime := currentModTime
            LoadActionTasks()
            RefreshMatrixBoard()
            ShowToast("🔄 Tasks automatically reloaded from updated CSV", 1500)
        }
    }
}

PerformWeeklyTasksBackup() {
    global ActionTasksFile, DataDir
    if !FileExist(ActionTasksFile)
        return
        
    backupDir := DataDir . "\Backups"
    if !DirExist(backupDir)
        DirCreate(backupDir)
        
    ; Current ISO Year and Week (e.g. tasks_backup_2026_W34.csv)
    weekNum := FormatTime(A_Now, "YWeek")
    weekStr := SubStr(weekNum, 1, 4) . "_W" . SubStr(weekNum, 5)
    backupTarget := backupDir . "\tasks_backup_" . weekStr . ".csv"
    
    ; If snapshot for this week doesn't exist yet, create it
    if !FileExist(backupTarget) {
        try {
            FileCopy(ActionTasksFile, backupTarget, 1)
        }
    }
}

ExportTasksManually() {
    global ActionTasksFile, DataDir
    if !FileExist(ActionTasksFile) {
        ShowToast("⚠️ No tasks file to export", 1500)
        return
    }
    
    backupDir := DataDir . "\Backups"
    if !DirExist(backupDir)
        DirCreate(backupDir)
        
    timeStr := FormatTime(A_Now, "yyyyMMdd_HHmmss")
    targetFile := backupDir . "\tasks_export_" . timeStr . ".csv"
    
    try {
        FileCopy(ActionTasksFile, targetFile, 1)
        ShowToast("✔ Exported snapshot to:`n" . targetFile, 3000)
    } catch as err {
        ShowToast("⚠️ Export failed: " . err.Message, 2000)
    }
}

ImportTasksPrompt() {
    global ActionTasks, ActionTasksFile
    selectedFile := FileSelect(3,, "Select CSV file to import tasks from", "CSV Files (*.csv)")
    if (selectedFile = "")
        return
        
    try {
        content := FileRead(selectedFile, "UTF-8")
        rows := ParseFullCSV(content)
        importedCount := 0
        
        for rIdx, row in rows {
            if (rIdx = 1 && row.Length >= 1 && StrLower(Trim(row[1])) = "id")
                continue
            if (row.Length >= 6) {
                t := Trim(row[2])
                if (t = "")
                    continue
                c := row[3]
                ct := row[4]
                p := NormalizePriority(Trim(row[5]))
                d := (StrLower(Trim(row[6])) = "true" || Trim(row[6]) = "1")
                
                ; Check if task already exists
                exists := false
                for existing in ActionTasks {
                    if (existing.task = t) {
                        exists := true
                        break
                    }
                }
                
                if !exists {
                    newId := ActionTasks.Length > 0 ? ActionTasks[ActionTasks.Length].id + 1 : 1
                    ActionTasks.Push({id: newId, task: t, created: c, commitmentType: ct, priority: p, done: d})
                    importedCount++
                }
            }
        }
        
        SaveActionTasks()
        RefreshMatrixBoard()
        ShowToast("✔ Successfully imported & merged " . importedCount . " new tasks!", 2500)
    } catch as err {
        ShowToast("⚠️ Import error: " . err.Message, 2500)
    }
}
