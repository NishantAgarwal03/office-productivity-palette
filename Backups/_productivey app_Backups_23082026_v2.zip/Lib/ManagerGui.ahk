; ======================================================================================================================
; Module: ManagerGui.ahk - Visual Snippet & Text Replacement Manager (Win+Esc)
; ======================================================================================================================

ToggleManagerGui() {
    global ManagerGui
    if IsObject(ManagerGui) {
        if WinActive(ManagerGui.Hwnd) {
            ManagerGuiClose(ManagerGui)
            return
        }
        ManagerGui.Show()
        return
    }
    CreateManagerGui()
}

CreateManagerGui() {
    global ManagerGui, ManagerListView, ManagerSearch, ManagerStatus, ManagerPos

    ManagerGui := Gui("+Resize +MinSize680x360")
    ManagerGui.Title := "Text Replacement & Snippet Manager"
    ManagerGui.SetFont("s9", "Segoe UI")
    
    ManagerGui.OnEvent("Close", (g) => ManagerGuiClose(g))
    ManagerGui.OnEvent("Size", (g, m, w, h) => ManagerGuiSize(g, m, w, h))

    ManagerGui.Add("Text", "x12 y12 w55", "🔍 Filter:")
    ManagerSearch := ManagerGui.Add("Edit", "x72 y9 w596 h24 vSearchFilter", "")
    ManagerSearch.OnEvent("Change", (ctrl, *) => RefreshManagerListView(ctrl.Value))

    ManagerListView := ManagerGui.AddListView("x12 y40 w656 h280 Grid -Multi", ["Trigger", "Replacement Text", "Enabled"])
    ManagerListView.OnEvent("DoubleClick", (*) => ManagerEditItem())

    ManagerGui.AddButton("x12 y335 w75 h30 vBtnAdd", "Add").OnEvent("Click", (*) => ManagerAddItem())
    ManagerGui.AddButton("x92 y335 w75 h30 vBtnEdit", "Edit").OnEvent("Click", (*) => ManagerEditItem())
    ManagerGui.AddButton("x172 y335 w75 h30 vBtnDel", "Delete").OnEvent("Click", (*) => ManagerDeleteItem())
    ManagerGui.AddButton("x252 y335 w75 h30 vBtnToggle", "Toggle").OnEvent("Click", (*) => ManagerToggleItem())

    ManagerGui.AddButton("x435 y335 w75 h30 vBtnImport", "Import").OnEvent("Click", (*) => ManagerImportData())
    ManagerGui.AddButton("x515 y335 w75 h30 vBtnExport", "Export").OnEvent("Click", (*) => ManagerExportData())
    ManagerGui.AddButton("x595 y335 w75 h30 vBtnHelp", "❓ Help").OnEvent("Click", (*) => ShowProductivityHelp())

    ManagerStatus := ManagerGui.Add("StatusBar",, "Ready")

    RefreshManagerListView()

    w := Max(680, ManagerPos.w)
    h := Max(360, ManagerPos.h)
    CenterGuiOnActiveMonitor(ManagerGui, w, h)
    ManagerGui.Show("w" . w . " h" . h)
}

ManagerGuiClose(TheGui) {
    global ManagerPos
    local x, y, w, h
    TheGui.GetPos(&x, &y, &w, &h)
    ManagerPos.x := x
    ManagerPos.y := y
    ManagerPos.w := w
    ManagerPos.h := h
    TheGui.Hide()
}

ManagerGuiSize(TheGui, MinMax, Width, Height) {
    global ManagerListView, ManagerSearch, ManagerStatus
    if MinMax = -1
        return
    
    if IsObject(ManagerSearch)
        ManagerSearch.Move(,, Width - 84)
    
    if IsObject(ManagerListView) {
        ManagerListView.Move(,, Width - 24, Max(80, Height - 125))
        try {
            col1W := 95
            col3W := 65
            col2W := Max(120, Width - 24 - col1W - col3W - 28)
            ManagerListView.ModifyCol(1, col1W)
            ManagerListView.ModifyCol(3, col3W)
            ManagerListView.ModifyCol(2, col2W)
        }
    }

    btnY := Height - 65
    try {
        TheGui["BtnAdd"].Move(12, btnY)
        TheGui["BtnEdit"].Move(92, btnY)
        TheGui["BtnDel"].Move(172, btnY)
        TheGui["BtnToggle"].Move(252, btnY)

        TheGui["BtnImport"].Move(Width - 245, btnY)
        TheGui["BtnExport"].Move(Width - 165, btnY)
        TheGui["BtnHelp"].Move(Width - 85, btnY)
    }
}

RefreshManagerListView(filter := "") {
    global ManagerListView, ManagerSearch, CustomSnippets, ManagerStatus
    if !IsObject(ManagerListView)
        return

    ManagerListView.Delete()
    filterLower := StrLower(Trim(filter))
    matchCount := 0

    for Item in CustomSnippets {
        if (filterLower != "") {
            if (!InStr(StrLower(Item.trigger), filterLower) && !InStr(StrLower(Item.replacement), filterLower))
                continue
        }
        matchCount++
        enText := Item.enabled ? "Yes" : "No"
        prev := StrLen(Item.replacement) > 70 ? SubStr(Item.replacement, 1, 67) . "..." : Item.replacement
        prev := StrReplace(prev, "`n", " ↵ ")
        ManagerListView.Add("", Item.trigger, prev, enText)
    }

    if IsObject(ManagerStatus) {
        if (filterLower != "")
            ManagerStatus.SetText("Filter: '" . filter . "' - Showing " . matchCount . " of " . CustomSnippets.Length . " snippets")
        else
            ManagerStatus.SetText("Ready - Total snippets: " . CustomSnippets.Length)
    }
}

ManagerAddItem() {
    global ManagerSearch, CustomSnippets
    res := ShowSnippetEditDialog()
    if (res.OK) {
        for Item in CustomSnippets {
            if (StrLower(Item.trigger) = StrLower(res.Trigger)) {
                MsgBox("Trigger '" . res.Trigger . "' already exists. Choose a unique one.", AppTitle, "Icon!")
                return
            }
        }
        CustomSnippets.Push({trigger: res.Trigger, replacement: res.Replacement, enabled: res.Enabled})
        SaveCustomSnippets()
        RegisterDynamicHotstrings()
        RefreshManagerListView(IsObject(ManagerSearch) ? ManagerSearch.Value : "")
    }
}

ManagerEditItem() {
    global ManagerListView, ManagerSearch, CustomSnippets
    selRow := ManagerListView.GetNext()
    if (!selRow) {
        MsgBox("Please select an item to edit.", AppTitle, "Icon!")
        return
    }

    triggerText := ManagerListView.GetText(selRow, 1)
    targetIdx := 0
    for idx, Item in CustomSnippets {
        if (Item.trigger = triggerText) {
            targetIdx := idx
            break
        }
    }
    if (targetIdx = 0)
        targetIdx := selRow

    item := CustomSnippets[targetIdx]
    res := ShowSnippetEditDialog(item.trigger, item.replacement, item.enabled)

    if (res.OK) {
        for idx, chk in CustomSnippets {
            if (idx != targetIdx && StrLower(chk.trigger) = StrLower(res.Trigger)) {
                MsgBox("Trigger '" . res.Trigger . "' already exists. Choose a unique one.", AppTitle, "Icon!")
                return
            }
        }
        CustomSnippets[targetIdx] := {trigger: res.Trigger, replacement: res.Replacement, enabled: res.Enabled}
        SaveCustomSnippets()
        RegisterDynamicHotstrings()
        RefreshManagerListView(IsObject(ManagerSearch) ? ManagerSearch.Value : "")
    }
}

ManagerDeleteItem() {
    global ManagerListView, ManagerSearch, CustomSnippets
    selRow := ManagerListView.GetNext()
    if (!selRow) {
        MsgBox("Please select an item to delete.", AppTitle, "Icon!")
        return
    }

    triggerText := ManagerListView.GetText(selRow, 1)
    targetIdx := 0
    for idx, Item in CustomSnippets {
        if (Item.trigger = triggerText) {
            targetIdx := idx
            break
        }
    }
    if (targetIdx = 0)
        targetIdx := selRow

    if (MsgBox("Are you sure you want to delete trigger '" . CustomSnippets[targetIdx].trigger . "'?", "Confirm Delete", "YesNo Default2 Icon?") = "Yes") {
        CustomSnippets.RemoveAt(targetIdx)
        SaveCustomSnippets()
        RegisterDynamicHotstrings()
        RefreshManagerListView(IsObject(ManagerSearch) ? ManagerSearch.Value : "")
    }
}

ManagerToggleItem() {
    global ManagerListView, CustomSnippets
    selRow := ManagerListView.GetNext()
    if (!selRow) {
        MsgBox("Please select an item to toggle.", AppTitle, "Icon!")
        return
    }

    triggerText := ManagerListView.GetText(selRow, 1)
    targetIdx := 0
    for idx, Item in CustomSnippets {
        if (Item.trigger = triggerText) {
            targetIdx := idx
            break
        }
    }
    if (targetIdx = 0)
        targetIdx := selRow

    item := CustomSnippets[targetIdx]
    item.enabled := !item.enabled

    SaveCustomSnippets()
    RegisterDynamicHotstrings()

    enText := item.enabled ? "Yes" : "No"
    prev := StrLen(item.replacement) > 70 ? SubStr(item.replacement, 1, 67) . "..." : item.replacement
    prev := StrReplace(prev, "`n", " ↵ ")
    ManagerListView.Modify(selRow, "", item.trigger, prev, enText)
}

ShowSnippetEditDialog(initTrigger := "", initReplacement := "", initEnabled := true) {
    global ManagerGui
    ownerParam := IsObject(ManagerGui) ? ("+Owner" . ManagerGui.Hwnd) : ""
    editG := Gui(ownerParam)
    editG.Title := initTrigger ? "Edit Snippet" : "Add Snippet"
    editG.SetFont("s9", "Segoe UI")

    editG.AddText("x12 y10", "Trigger keyword (case-insensitive whole word):")
    trigCtrl := editG.AddEdit("x12 y30 w396 r1", initTrigger)

    editG.AddText("x12 y70", "Replacement Text (multi-line supported):")
    repCtrl := editG.AddEdit("x12 y90 w396 h130 VScroll", initReplacement)

    enCtrl := editG.AddCheckbox("x12 y230 Checked" . initEnabled, "Enabled")

    btnOk := editG.AddButton("x242 y260 w80 h30 Default", "OK")
    btnCancel := editG.AddButton("x328 y260 w80 h30", "Cancel")

    result := {OK: false, Trigger: "", Replacement: "", Enabled: true}

    OnOk(*) {
        if Trim(trigCtrl.Value) = "" {
            MsgBox("Trigger keyword cannot be empty.", AppTitle, "Icon!")
            return
        }
        result.OK := true
        result.Trigger := Trim(trigCtrl.Value)
        result.Replacement := repCtrl.Value
        result.Enabled := !!enCtrl.Value
        editG.Destroy()
    }

    OnCancel(*) => editG.Destroy()

    btnOk.OnEvent("Click", OnOk)
    btnCancel.OnEvent("Click", OnCancel)
    editG.OnEvent("Close", OnCancel)

    if IsObject(ManagerGui)
        ManagerGui.Opt("+Disabled")

    editG.Show("w420 h305")
    WinWaitClose(editG)

    if IsObject(ManagerGui) {
        ManagerGui.Opt("-Disabled")
        ManagerGui.Show()
    }

    return result
}

ManagerImportData() {
    global SnippetsFile, CustomSnippets
    importPath := FileSelect(1, , "Import Snippets from CSV", "CSV Files (*.csv)")
    if !importPath
        return

    try {
        backup := CustomSnippets.Clone()
        content := FileRead(importPath, "UTF-8")
        rows := ParseFullCSV(content)
        imported := []

        for rIdx, row in rows {
            if (rIdx = 1 && row.Length >= 1 && StrLower(Trim(row[1])) = "trigger")
                continue
            if (row.Length >= 3) {
                t := Trim(row[1])
                if (t = "")
                    continue
                r := StrReplace(row[2], "\n", "`n")
                e := (StrLower(Trim(row[3])) = "true" || Trim(row[3]) = "1")
                imported.Push({trigger: t, replacement: r, enabled: e})
            }
        }

        CustomSnippets := imported
        SaveCustomSnippets()
        RegisterDynamicHotstrings()
        RefreshManagerListView()
        MsgBox("Successfully imported " . imported.Length . " snippets!", AppTitle, "Iconi")
    } catch as err {
        CustomSnippets := backup
        LogAppError("ManagerImportData", err)
        MsgBox("Import failed: " . err.Message, AppTitle . " - Import Error", "Icon!")
    }
}

ManagerExportData() {
    global SnippetsFile
    exportPath := FileSelect("S", "office_snippets_backup_" . FormatTime(A_Now, "yyMMdd") . ".csv", "Export Snippets to CSV", "CSV Files (*.csv)")
    if !exportPath
        return
    try {
        FileCopy(SnippetsFile, exportPath, 1)
        MsgBox("Data exported successfully to:`n" . exportPath, AppTitle, "Iconi")
    } catch as err {
        LogAppError("ManagerExportData", err)
        MsgBox("Export error: " . err.Message, AppTitle . " - Export Error", "Icon!")
    }
}

IsManagerActive() {
    global ManagerGui
    try {
        if IsObject(ManagerGui) && WinActive(ManagerGui.Hwnd)
            return true
    }
    return false
}
