# ⚡ Office Productivity Command Palette & Visual Action Hub (v2.0.0 Production Release)

> **Core Purpose:** A bulletproof, keyboard-driven Windows office productivity hub that unifies 70+ essential tools, instant data extraction, Indian financial & GST analytics, 4-Quadrant visual Eisenhower matrix board, automatic file sync, weekly backups, and on-the-fly snippet expansion.

---

## 🚀 Master Shortcuts Reference

| Shortcut                              | Action                           | Description                                                                   |
| ------------------------------------- | -------------------------------- | ----------------------------------------------------------------------------- |
| **`Win + T`** / **`Win + Shift + T`** | **📋 Visual Action Board**       | 4-Quadrant Eisenhower Matrix Grid with native dark theme                      |
| **`Double-Shift`**                    | **🔍 Universal Command Palette** | JetBrains-style spotlight search across all 70+ built-in actions & snippets   |
| **`Double-Ctrl`**                     | **📌 Commitment Catcher**        | Instantly captures mouse-highlighted text into Action Board                   |
| **`Win + 0`** / **`Ctrl + 0`**        | **🔁 Repeat Last Action**        | Instantly re-executes the most recently used transformation or tool           |
| **`Win + Esc`**                       | **⚡ Snippet Manager**            | Visual GUI to create, search, and manage text expansion abbreviations         |
| **`1` .. `9`**                        | **Instant Numeric Execution**    | In Command Palette, tap `1`..`9` to run the corresponding result              |
| **`Trigger + Space`**                 | **Direct Hotstring Expansion**   | Expands saved trigger keywords directly in text (e.g. `myemail `, `myphone `) |

---

## 🏛️ Catalog of All Built-In Office Features & Examples

### 🔍 1. Text Mining & Data Extraction Suite (7 Tools)

*Pulls clean, deduplicated lists from messy emails, PDFs, website text, or notices and copies/pastes them newline-separated.*

| #   | Tool Name                          | Shortcut | Output / Behavior                                     | Example                                                                                                                             |
| --- | ---------------------------------- | -------- | ----------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| 1   | **Extract All Email Addresses**    | `[1]`    | Pulls clean list of all valid email addresses.        | **Input:** `"Contact john@test.com or billing@corp.in"`<br>**Output:** `john@test.com`<br>`billing@corp.in`                         |
| 2   | **Extract All URLs & Web Links**   | `[2]`    | Pulls clean list of all web URLs and links.           | **Input:** `"See https://incometax.gov.in and www.gst.gov.in"`<br>**Output:** `https://incometax.gov.in`<br>`http://www.gst.gov.in` |
| 3   | **Extract Phone & Mobile Numbers** | `[3]`    | Pulls 10-digit Indian mobiles and landlines.          | **Input:** `"Call +91 98765-43210 or 022-24567890"`<br>**Output:** `+91 98765 43210`<br>`022-24567890`                              |
| 4   | **Extract Indian GSTINs**          | `[4]`    | Validates and extracts 15-character GST numbers.      | **Input:** `"Vendor GSTIN: 27ABCDE1234F1Z5 for Maharashtra"`<br>**Output:** `27ABCDE1234F1Z5`                                       |
| 5   | **Extract Indian PAN Numbers**     | `[5]`    | Validates and extracts 10-character PANs.             | **Input:** `"Director PAN is ABCDE1234F on filing"`<br>**Output:** `ABCDE1234F`                                                     |
| 6   | **Extract All Dates from Text**    | `[6]`    | Pulls all dates in any format.                        | **Input:** `"Filed on 21/07/2026 and due by 2026-08-15"`<br>**Output:** `21/07/2026`<br>`2026-08-15`                                |
| 7   | **Date Difference & Working Days** | `[7]`    | Calculates total calendar and working days (Mon–Fri). | **Input:** `"2026-08-01 to 2026-08-31"`<br>**Output:** `Total Days: 30                                                              |

---

### 💼 2. Indian Fiscal & Financial Analytics (8 Tools)

| #   | Tool Name                             | Shortcut | Output / Behavior                                               | Example                                                                                            |
| --- | ------------------------------------- | -------- | --------------------------------------------------------------- | -------------------------------------------------------------------------------------------------- |
| 8   | **Indian Financial Year & Quarter**   | `↵`      | Converts any date into Indian Fiscal Year format.               | **Input:** `2026-08-22`<br>**Output:** `FY 2026–27 (Q2)`                                           |
| 9   | **Percentage vs Point (pp) Change**   | `↵`      | Compares two rates with percentage and percentage-point deltas. | **Input:** `5.0% 6.5%`<br>**Output:** `+1.50 pp (+30.00%)`                                         |
| 10  | **CAGR Growth Calculator**            | `↵`      | Calculates Compound Annual Growth Rate.                         | **Input:** `Begin: 100000, End: 250000, Years: 5`<br>**Output:** `CAGR: 20.11%`                    |
| 11  | **Reverse GST Calculator (18%)**      | `↵`      | Extracts Taxable Base + 18% GST (CGST/SGST) from total.         | **Input:** `11800`<br>**Output:** `Taxable Base: ₹10,000.00                                        |
| 12  | **Reverse GST (Custom Rate)**         | `↵`      | Extracts Taxable Base + Tax for 5%, 12%, 18%, or 28%.           | **Input:** `Amount: 1050, Rate: 5%`<br>**Output:** `Base: ₹1,000.00                                |
| 13  | **Clean Number to Raw Machine Value** | `↵`      | Normalizes verbal units, European decimals, and commas.         | **Input:** `1.25 Lakh`<br>**Output:** `125000`<br>**Input:** `1.250,50 €`<br>**Output:** `1250.50` |
| 14  | **Format with Indian Commas**         | `↵`      | Formats number with Indian comma grouping (Lakhs/Crores).       | **Input:** `12345678`<br>**Output:** `1,23,45,678`                                                 |
| 15  | **Format with International Commas**  | `↵`      | Formats number with standard 3-digit comma grouping.            | **Input:** `12345678`<br>**Output:** `12,345,678`                                                  |

---

### 📋 3. Commitment Catcher & Visual Task Board (2 Tools)

| #   | Tool Name                         | Shortcut      | Output / Behavior                                                              |
| --- | --------------------------------- | ------------- | ------------------------------------------------------------------------------ |
| 16  | **Open Action Board & Tasks**     | `Win + T`     | Opens the visual 4-Quadrant Eisenhower Matrix grid.                            |
| 17  | **Capture Selected Text as Task** | `Double-Ctrl` | Saves highlighted text as an action item into `office_productivity_tasks.csv`. |

---

### 📅 4. Date & Time Master (10 Tools)

| #   | Tool Name                   | Shortcut       | Output Preview / Behavior                    | Example Output             |
| --- | --------------------------- | -------------- | -------------------------------------------- | -------------------------- |
| 18  | **Today's ISO Date**        | `^; d` / `[1]` | Inserts standard ISO date (`YYYY-MM-DD`).    | `2026-08-23`               |
| 19  | **Compact File Timestamp**  | `^; t` / `[2]` | Inserts compact timestamp (`YYMMDD_HHMMSS`). | `260823_061500`            |
| 20  | **Formal Long Date**        | `[3]`          | Inserts full weekday, month, day, and year.  | `Sunday, August 23, 2026`  |
| 21  | **Current Time (12-Hour)**  | `[4]`          | Inserts 12-hour clock with AM/PM.            | `06:15 AM`                 |
| 22  | **Current Time (24-Hour)**  | `[5]`          | Inserts 24-hour military clock with seconds. | `06:15:22`                 |
| 23  | **Tomorrow's Date**         | `[6]`          | Calculates and inserts tomorrow's date.      | `2026-08-24`               |
| 24  | **Yesterday's Date**        | `[7]`          | Calculates and inserts yesterday's date.     | `2026-08-22`               |
| 25  | **Current ISO Week Number** | `[8]`          | Inserts sprint/work-week string.             | `Week 34, 2026`            |
| 26  | **Current Month & Year**    | `[9]`          | Inserts billing period title.                | `August 2026`              |
| 27  | **Work Week Date Range**    | `↵`            | Inserts Monday-to-Friday range.              | `2026-08-17 to 2026-08-21` |

---

### 🔤 5. Text Formatting & Case Transformers (10 Tools)

| #   | Tool Name                            | Shortcut | Transformation Applied                                       | Detailed Before & After Example                                                                                                                                                                                                                            |
| --- | ------------------------------------ | -------- | ------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 28  | **Paste Clean Plain Text**           | `^; v`   | Strips all HTML/rich styling, colors, and font formatting.   | **Input (Styled Clipboard):** `<b><font color="#FF0000">Invoice Total: $1,500</font></b>`<br>**Output (Pasted Plain Text):** `Invoice Total: $1,500`                                                                                                       |
| 29  | **Convert to UPPERCASE**             | `^; u`   | Converts selected text to all capital letters.               | **Input:** `quarterly statutory compliance report`<br>**Output:** `QUARTERLY STATUTORY COMPLIANCE REPORT`                                                                                                                                                  |
| 30  | **Convert to lowercase**             | `^; l`   | Converts selected text to all small letters.                 | **Input:** `GOODS AND SERVICES TAX IDENTIFICATION NUMBER`<br>**Output:** `goods and services tax identification number`                                                                                                                                    |
| 31  | **Convert to Title Case**            | `↵`      | Capitalizes the first letter of each word.                   | **Input:** `annual general meeting of directors and shareholders`<br>**Output:** `Annual General Meeting Of Directors And Shareholders`                                                                                                                    |
| 32  | **Convert to Sentence case**         | `↵`      | Capitalizes the first letter of each sentence in paragraphs. | **Input:** `invoice approved. please process payment today. thanks.`<br>**Output:** `Invoice approved. Please process payment today. Thanks.`                                                                                                              |
| 33  | **Convert to snake_case**            | `↵`      | Replaces spaces and symbols with lowercase underscores.      | **Input:** `User Bank Account Number`<br>**Output:** `user_bank_account_number`                                                                                                                                                                            |
| 34  | **Convert to kebab-case**            | `↵`      | Replaces spaces and symbols with lowercase hyphens.          | **Input:** `User Authentication Token`<br>**Output:** `user-authentication-token`                                                                                                                                                                          |
| 35  | **Convert to camelCase**             | `↵`      | Lowercases first word and capitalizes subsequent words.      | **Input:** `Gross Taxable Invoice Amount`<br>**Output:** `grossTaxableInvoiceAmount`                                                                                                                                                                       |
| 36  | **Quote Lines (SQL IN list)**        | `↵`      | Formats multiline items into SQL `IN (...)` syntax.          | **Input:**<br>`INV-1001`<br>`INV-1002`<br>`INV-1003`<br>**Output:** `('INV-1001', 'INV-1002', 'INV-1003')`                                                                                                                                                 |
| 37  | **Join Lines into Single Paragraph** | `↵`      | Unwraps hard line breaks from copied PDFs and scans.         | **Input:**<br>`The company has completed the internal`<br>`audit for Q2 with no adverse`<br>`qualifications or compliance flags.`<br>**Output:** `The company has completed the internal audit for Q2 with no adverse qualifications or compliance flags.` |

---

### ✉️ 6. Professional Email Templates (10 Tools)

| #   | Tool Name                               | Template Content                                                                                                                                              |
| --- | --------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 38  | **Email: Please Find Attached (PFA)**   | `Please find the requested file(s) attached for your review.`                                                                                                 |
| 39  | **Email: Acknowledgment & Follow-Up**   | `Acknowledged with thanks. I am reviewing this and will update you shortly.`                                                                                  |
| 40  | **Email: Meeting Availability Request** | `Could you please share your availability for a brief sync this week?`                                                                                        |
| 41  | **Email: Gentle Follow-Up / Reminder**  | `Just following up on my previous note to check if there are any updates on this.`                                                                            |
| 42  | **Email: Out of Office Notice**         | `Thank you for your email. I am currently out of the office with limited access to email. I will respond to your message as soon as possible upon my return.` |
| 43  | **Email: Formal Business Greeting**     | `Dear [Name],`                                                                                                                                                |
| 44  | **Email: Formal Sign-Off**              | `Best regards,` + signature placeholder.                                                                                                                      |
| 45  | **Email: Action Required Notice**       | `ACTION REQUIRED: Please review and confirm by EOD.`                                                                                                          |
| 46  | **Email: Handover / Delegation Note**   | `I am looping in [Name] who will assist you further with this request.`                                                                                       |
| 47  | **Email: Appreciation Note**            | `Thank you for your prompt assistance and support on this matter.`                                                                                            |

---

### 🧮 7. Math, Tax & Currency Calculators (11 Tools)

| #   | Tool Name                            | Shortcut | How it Works                                                                                    | Example                                                                                                                   |
| --- | ------------------------------------ | -------- | ----------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| 48  | **Evaluate Math Expression**         | `^; c`   | Evaluates arithmetic, dimensions, markup (`+18%`), discount (`-10%`), brackets, and currencies. | **Input:** `1500x300x87` $\rightarrow$ `39150000`<br>**Input:** `2500+18%` $\rightarrow$ `2950`                           |
| 49  | **Number to Words (Indian Rupees)**  | `^; w`   | Converts numbers up to **₹10,000 Crore (Level 5)** with Paise.                                  | **Input:** `1254320.50`<br>**Output:** `Rupees Twelve Lakh Fifty-Four Thousand Three Hundred Twenty and Fifty Paise Only` |
| 50  | **GST / Tax Breakdown (18%)**        | `↵`      | Calculates Base, 18% GST, and Total.                                                            | **Input:** `1000`<br>**Output:** `Base: 1000.00                                                                           |
| 51  | **Percentage Difference Calculator** | `↵`      | Computes percentage change between two numbers.                                                 | **Input:** `100 125`<br>**Output:** `100.00 -> 125.00 (+25.00%)`                                                          |
| 52  | **Generate 16-Char Secure Password** | `↵`      | Generates high-entropy random password.                                                         | `aB9#mK2$xP8!vQ4@`                                                                                                        |
| 53  | **Generate UUID / GUID v4**          | `↵`      | Generates standard UUID v4 string.                                                              | `c83f9821-4f81-4235-bc32-11a5b8f2d87e`                                                                                    |
| 54  | **Word & Character Counter**         | `↵`      | Shows popup stats dialog with word, char, and line counts.                                      | `Words: 142                                                                                                               |
| 55  | **Format Number with Commas**        | `↵`      | Formats standard international commas.                                                          | `1000000` $\rightarrow$ `1,000,000`                                                                                       |
| 56  | **Round Number to 2 Decimals**       | `↵`      | Rounds float numbers to 2 decimal places.                                                       | `1234.5678` $\rightarrow$ `1234.57`                                                                                       |
| 57  | **Sum Column of Selected Numbers**   | `↵`      | Sums all numbers in highlighted multi-line selection.                                           | **Input:** `100\n250\n450`<br>**Output:** `Sum (3 numbers): 800.00`                                                       |
| 58  | **Unix Timestamp to Readable Date**  | `↵`      | Converts epoch seconds into human date.                                                         | `1787385200` $\rightarrow$ `2026-08-22 20:46:40`                                                                          |

---

### 📁 8. File, Path & System Utilities (10 Tools)

| #   | Tool Name                               | Environment     | How it Works                                                                                             | Detailed Example                                                                                                                                  |
| --- | --------------------------------------- | --------------- | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| 59  | **Copy File Path (Forward Slashes)**    | Explorer / Text | Converts Windows backslashes to forward slashes. In editor -> **automatically pastes** converted path!   | **Explorer Selection:** `C:\Projects\Audit\Report.xlsx`<br>**Copied / Pasted:** `C:/Projects/Audit/Report.xlsx` (ready for Python, Git, Markdown) |
| 60  | **Copy File Path (Escaped Slashes)**    | Explorer / Text | Escapes all backslashes for programming and JSON. In editor -> **automatically pastes**!                 | **Input:** `C:\Users\Admin\Docs\File.txt`<br>**Copied / Pasted:** `C:\\Users\\Admin\\Docs\\File.txt` (ready for C#, Regex, JSON configs)          |
| 61  | **Prefix Selected File with Timestamp** | Explorer        | Renames selected file or folder in Explorer to `YYMMDD_name` in-place using native `DirMove`/`FileMove`. | **Selected File:** `Contract_Draft.docx`<br>**Renamed File:** `260823_Contract_Draft.docx`                                                        |
| 62  | **Google Search Selected Text**         | Any             | Launches default browser searching highlighted text or prompt query.                                     | **Selected Text:** `Section 194C TDS Limit`<br>**Action:** Opens browser to `https://www.google.com/search?q=Section+194C+TDS+Limit`              |
| 63  | **Google Translate Selected Text**      | Any             | Opens Google Translate in default browser with selected text pre-filled.                                 | **Selected Text:** `Merci pour votre aide`<br>**Action:** Opens Google Translate with source text loaded                                          |
| 64  | **Toggle Window Always-on-Top**         | System          | Pins active window (Calculator, Notepad, Browser) to float above all other apps.                         | **Scenario:** Keep Windows Calculator floating on top while entering figures into Excel.                                                          |
| 65  | **Toggle Window Transparency (75%)**    | System          | Toggles 75% opacity on active window for comparing overlaid documents.                                   | **Scenario:** Make a draft PDF semi-transparent to check alignment against underlying spreadsheet.                                                |
| 66  | **Open Today's Daily Scratchpad Notes** | System          | Automatically creates/opens timestamped daily notes file (`Scratchpad_YYYY_MM_DD.txt`) in Notepad.       | **Action:** Opens `C:\Users\Admin\Documents\AutoHotkey\Final versions of ahk files\New folder\Scratchpad_2026_08_23.txt`                          |
| 67  | **Empty Windows Recycle Bin**           | System          | Silently purges all items from Windows Recycle Bin and confirms with a toast notification.               | **Action:** Empties Recycle Bin without prompting confirmation popups.                                                                            |
| 68  | **Quick Privacy Screen / Lock**         | System          | Instantly locks the Windows workstation (`Win+L`).                                                       | **Shortcut:** `Win + Shift + L` $\rightarrow$ Instantly locks screen when stepping away from desk.                                                |

---

## 🏛️ Modular Project Architecture

```text
📁 New folder\
├── main.ahk                          ; Master entry point, global hotkeys, Double-Shift & Double-Ctrl (170 lines)
├── office_productivity_tasks.csv     ; Active tasks database (Auto-synced & watched)
├── office_productivity_snippets.csv  ; User custom snippets database (CSV)
├── office_productivity_errors.log    ; Timestamped error logger
├── README_office_productivity_palette.md ; Complete documentation & manual
├── 📁 Backups\                       ; Weekly automated timestamped snapshots
└── 📁 Lib\
    ├── Core.ahk                      ; Fail-safe clipboard engine, CSV parser, Repeat Action, path resolver
    ├── PaletteGui.ahk                ; Command palette spotlight GUI & dynamic accordion
    ├── ManagerGui.ahk                ; Visual snippet manager GUI (CRUD + Import/Export)
    ├── ActionBoardGui.ahk            ; 4-Quadrant Eisenhower Matrix, custom-draw, sync & backup
    ├── Actions_Extraction.ahk        ; 7 Data extraction & date difference tools
    ├── Actions_Finance.ahk           ; 8 Indian FY, Reverse GST, CAGR & number tools
    ├── Actions_DateTime.ahk          ; 10 Date & Time tools
    ├── Actions_Text.ahk              ; 10 Text formatting & case converters
    ├── Actions_Email.ahk             ; 10 Professional email templates
    ├── Actions_Math.ahk              ; 11 Math, Indian words & tax calculators
    └── Actions_Utility.ahk           ; 10 File, path & system utilities
```
