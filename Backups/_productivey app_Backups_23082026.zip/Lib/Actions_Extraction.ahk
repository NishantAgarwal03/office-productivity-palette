; ======================================================================================================================
; Module: Actions_Extraction.ahk - Text Mining & Data Extraction Suite
; ======================================================================================================================

RegisterExtractionActions() {
    RegisterAction("Extract All Email Addresses", "🔍 Extraction", "[Needs Selection] Pulls clean list of all emails from messy text", "extract, email, emails, mail, filter, list", (*) => ProcessExtraction("Emails", (txt) => ExtractEmails(txt)))
    RegisterAction("Extract All URLs & Web Links", "🔍 Extraction", "[Needs Selection] Pulls clean list of all web URLs and links", "extract, url, urls, links, web, http, list", (*) => ProcessExtraction("URLs", (txt) => ExtractUrls(txt)))
    RegisterAction("Extract Phone & Mobile Numbers", "🔍 Extraction", "[Needs Selection] Pulls Indian mobile and STD phone numbers", "extract, phone, mobile, contact, numbers, call", (*) => ProcessExtraction("Phone Numbers", (txt) => ExtractPhones(txt)))
    RegisterAction("Extract Indian GSTINs", "🔍 Extraction", "[Needs Selection] Pulls 15-char GST Identification Numbers", "extract, gstin, gst, tax, invoice, compliance", (*) => ProcessExtraction("GSTINs", (txt) => ExtractGstin(txt)))
    RegisterAction("Extract Indian PAN Numbers", "🔍 Extraction", "[Needs Selection] Pulls 10-char Permanent Account Numbers", "extract, pan, tax, income tax, compliance", (*) => ProcessExtraction("PANs", (txt) => ExtractPan(txt)))
    RegisterAction("Extract All Dates from Text", "🔍 Extraction", "[Needs Selection] Pulls dates in all formats (DD/MM/YYYY, etc.)", "extract, date, dates, calendar, deadlines", (*) => ProcessExtraction("Dates", (txt) => ExtractDates(txt)))
    RegisterAction("Date Difference & Working Days", "🔍 Extraction", "[Needs Selection] Calculates calendar days and working days (Mon-Fri)", "date, difference, diff, days, working days, duration, between", (*) => CalculateDateDifferencePrompt())
}

ProcessExtraction(itemType, extractorFunc) {
    sel := SafeGetSelection()
    if (Trim(sel) = "") {
        ib := InputBox("No text was selected. Please paste the messy text to extract " . itemType . " from:", "Extract " . itemType, "w480 h170")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        sel := ib.Value
    }
    
    extracted := extractorFunc.Call(sel)
    if (extracted = "" || InStr(extracted, "No ")) {
        ShowToast("⚠️ No " . itemType . " found in text", 2000)
        return
    }
    
    ; Copy to clipboard permanently and paste if outside Explorer
    A_Clipboard := extracted
    if !WinActive("ahk_class CabinetWClass") && !WinActive("ahk_class ExploreWClass") && !WinActive("ahk_class Progman") && !WinActive("ahk_class WorkerW") {
        InsertText(extracted)
    }
    
    lineCount := StrSplit(extracted, "`n").Length
    ShowToast("✔ Extracted " . lineCount . " " . itemType . " (Copied to Clipboard)", 2500)
}

ExtractEmails(text) {
    emails := []
    pos := 1
    while RegExMatch(text, "i)[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}", &m, pos) {
        val := m[0]
        found := false
        for e in emails {
            if (StrLower(e) = StrLower(val)) {
                found := true
                break
            }
        }
        if !found
            emails.Push(val)
        pos := m.Pos + m.Len
    }
    if (emails.Length = 0)
        return "No emails found"
    res := ""
    for idx, e in emails
        res .= (idx > 1 ? "`n" : "") . e
    return res
}

ExtractUrls(text) {
    urls := []
    pos := 1
    while RegExMatch(text, "i)\b(?:https?://|www\.)[^\s<>'`"\)]+", &m, pos) {
        val := RTrim(m[0], ".,;:!?'`"")
        found := false
        for u in urls {
            if (u = val) {
                found := true
                break
            }
        }
        if !found
            urls.Push(val)
        pos := m.Pos + m.Len
    }
    if (urls.Length = 0)
        return "No URLs found"
    res := ""
    for idx, u in urls
        res .= (idx > 1 ? "`n" : "") . u
    return res
}

ExtractPhones(text) {
    phones := []
    pos := 1
    while RegExMatch(text, "(?:\+91[\-\s]?)?[6-9]\d{9}|\b\d{3,5}[\-\s]\d{6,8}\b", &m, pos) {
        val := Trim(m[0])
        found := false
        for p in phones {
            if (p = val) {
                found := true
                break
            }
        }
        if !found
            phones.Push(val)
        pos := m.Pos + m.Len
    }
    if (phones.Length = 0)
        return "No phone numbers found"
    res := ""
    for idx, p in phones
        res .= (idx > 1 ? "`n" : "") . p
    return res
}

ExtractGstin(text) {
    gstins := []
    pos := 1
    while RegExMatch(text, "\b\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1}\b", &m, pos) {
        val := m[0]
        found := false
        for g in gstins {
            if (g = val) {
                found := true
                break
            }
        }
        if !found
            gstins.Push(val)
        pos := m.Pos + m.Len
    }
    if (gstins.Length = 0)
        return "No GSTINs found"
    res := ""
    for idx, g in gstins
        res .= (idx > 1 ? "`n" : "") . g
    return res
}

ExtractPan(text) {
    pans := []
    pos := 1
    while RegExMatch(text, "\b[A-Z]{5}\d{4}[A-Z]{1}\b", &m, pos) {
        val := m[0]
        found := false
        for p in pans {
            if (p = val) {
                found := true
                break
            }
        }
        if !found
            pans.Push(val)
        pos := m.Pos + m.Len
    }
    if (pans.Length = 0)
        return "No PAN numbers found"
    res := ""
    for idx, p in pans
        res .= (idx > 1 ? "`n" : "") . p
    return res
}

ExtractDates(text) {
    dates := []
    pos := 1
    pattern := "\b(?:\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}[-/]\d{1,2}[-/]\d{2,4}|\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})\b"
    while RegExMatch(text, "i)" . pattern, &m, pos) {
        val := m[0]
        found := false
        for d in dates {
            if (d = val) {
                found := true
                break
            }
        }
        if !found
            dates.Push(val)
        pos := m.Pos + m.Len
    }
    if (dates.Length = 0)
        return "No dates found"
    res := ""
    for idx, d in dates
        res .= (idx > 1 ? "`n" : "") . d
    return res
}

CalculateDateDifferencePrompt() {
    sel := SafeGetSelection()
    dates := []
    if (Trim(sel) != "") {
        dText := ExtractDates(sel)
        if (!InStr(dText, "No dates")) {
            for line in StrSplit(dText, "`n") {
                if (Trim(line) != "")
                    dates.Push(Trim(line))
            }
        }
    }
    
    if (dates.Length < 2) {
        ib := InputBox("Enter two dates separated by 'and' or 'to' (e.g. 01/08/2026 to 22/08/2026):", "Date Difference Calculator", "w480 h160")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        dText := ExtractDates(ib.Value)
        dates := []
        for line in StrSplit(dText, "`n") {
            if (Trim(line) != "")
                dates.Push(Trim(line))
        }
        if (dates.Length < 2) {
            ShowToast("⚠️ Please provide at least two valid dates", 2000)
            return
        }
    }
    
    diffReport := CalculateDateDifference(dates[1], dates[2])
    MsgBox(diffReport, "Date Difference & Working Days", "Iconi")
}

CalculateDateDifference(dateStr1, dateStr2) {
    d1 := ParseAnyDateToYyyyMmDd(dateStr1)
    d2 := ParseAnyDateToYyyyMmDd(dateStr2)
    if (d1 = "" || d2 = "")
        return "Invalid date format"
    
    if (d1 > d2) {
        tmp := d1
        d1 := d2
        d2 := tmp
    }
    
    totalDays := DateDiff(d2 . "000000", d1 . "000000", "days")
    
    workDays := 0
    cur := d1
    Loop totalDays {
        wday := FormatTime(cur . "000000", "WDay")
        if (wday >= 2 && wday <= 6)
            workDays++
        cur := FormatTime(DateAdd(cur . "000000", 1, "days"), "yyyyMMdd")
    }
    
    weeks := totalDays // 7
    remDays := Mod(totalDays, 7)
    
    res := Format("From {} to {}:`n• Total Calendar Days: {} days`n• Working Days (Mon-Fri): {} days`n• Duration: {} week(s) {} day(s)", 
                  FormatTime(d1 . "000000", "dd-MMM-yyyy"), FormatTime(d2 . "000000", "dd-MMM-yyyy"), totalDays, workDays, weeks, remDays)
    return res
}

ParseAnyDateToYyyyMmDd(dStr) {
    s := Trim(dStr)
    if RegExMatch(s, "^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$", &m)
        return Format("{}{:02d}{:02d}", m[1], Integer(m[2]), Integer(m[3]))
    if RegExMatch(s, "^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$", &m)
        return Format("{}{:02d}{:02d}", m[3], Integer(m[2]), Integer(m[1]))
    if RegExMatch(s, "^(\d{1,2})[-/](\d{1,2})[-/](\d{2})$", &m)
        return Format("20{}{:02d}{:02d}", m[3], Integer(m[2]), Integer(m[1]))
    return ""
}
