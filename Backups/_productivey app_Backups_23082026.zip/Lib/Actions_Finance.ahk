; ======================================================================================================================
; Module: Actions_Finance.ahk - Indian Fiscal Year, Reverse GST, CAGR & Number Formatting
; ======================================================================================================================

RegisterFinanceActions() {
    RegisterAction("Indian Financial Year & Quarter", "💼 Finance", "[Needs Selection] Converts date to FY 2026–27 (Q2)", "fy, financial year, quarter, q1, q2, q3, q4, fiscal, tax", (*) => ProcessIndianFY())
    RegisterAction("Percentage Change vs Point (pp) Change", "💼 Finance", "[Needs Selection] Compares two rates (e.g. 5.0% -> 6.5% gives +1.5pp / +30%)", "percentage, point, pp, change, rate, yield, compare", (*) => ProcessPctVsPp())
    RegisterAction("CAGR Growth Calculator", "💼 Finance", "[Needs Selection] Calculates CAGR from Beg Val, End Val, Years", "cagr, growth, compound, annual, investment, returns", (*) => ProcessCAGR())
    RegisterAction("Reverse GST Calculator (18%)", "💼 Finance", "[Needs Selection] Extracts Base + 18% GST from inclusive amount", "reverse, gst, 18%, tax, base, inclusive, invoice", (*) => ProcessReverseGST(18))
    RegisterAction("Reverse GST (Custom Rate)", "💼 Finance", "Extracts Base + Tax for 5%, 12%, 18%, or 28% GST", "reverse, gst, rate, tax, 5%, 12%, 28%, custom", (*) => ProcessReverseGSTPrompt())
    RegisterAction("Clean Number to Raw Machine Value", "💼 Finance", "[Needs Selection] Converts '1.25 Lakh' / '2.5 Cr' / '1,25,000' -> 125000", "clean, number, machine, raw, lakh, crore, euro", (*) => TransformSelectedText((txt) => CleanToMachineNumber(txt)))
    RegisterAction("Format Number with Indian Commas", "💼 Finance", "[Needs Selection] Formats 12345678 -> 1,23,45,678 (Lakhs/Crores)", "comma, indian, lakh, crore, format, currency", (*) => TransformSelectedText((txt) => FormatIndianCommas(txt)))
    RegisterAction("Format Number with International Commas", "💼 Finance", "[Needs Selection] Formats 12345678 -> 12,345,678 (Millions/Billions)", "comma, international, million, format, standard", (*) => TransformSelectedText((txt) => FormatInternationalCommas(txt)))
}

ProcessIndianFY() {
    sel := SafeGetSelection()
    res := ResolveIndianFinancialYear(Trim(sel))
    InsertText(res)
}

ResolveIndianFinancialYear(dateStr := "") {
    if (dateStr = "")
        dt := A_Now
    else {
        parsed := ParseAnyDateToYyyyMmDd(dateStr)
        dt := (parsed != "") ? parsed . "000000" : A_Now
    }
    
    year := Integer(FormatTime(dt, "yyyy"))
    month := Integer(FormatTime(dt, "MM"))
    
    if (month >= 4) {
        fyStart := year
        fyEnd := SubStr(String(year + 1), 3, 2)
        qtr := (month <= 6) ? "Q1" : (month <= 9) ? "Q2" : "Q3"
    } else {
        fyStart := year - 1
        fyEnd := SubStr(String(year), 3, 2)
        qtr := "Q4"
    }
    
    return Format("FY {}-{} ({})", fyStart, fyEnd, qtr)
}

ProcessPctVsPp() {
    sel := SafeGetSelection()
    nums := []
    for match in StrSplit(RegExReplace(sel, "[^\d\.\-\s,]", " "), [" ", "`n", "`r", ","]) {
        if (Trim(match) != "" && IsNumber(match))
            nums.Push(Float(match))
    }
    if (nums.Length < 2) {
        ib := InputBox("Enter initial rate and final rate (e.g. '5.0 6.5' for 5% to 6.5%):", "Percentage vs Percentage-Point Change", "w480 h160")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        for match in StrSplit(RegExReplace(ib.Value, "[^\d\.\-\s,]", " "), [" ", "`n", "`r", ","]) {
            if (Trim(match) != "" && IsNumber(match))
                nums.Push(Float(match))
        }
        if (nums.Length < 2)
            return
    }
    report := CalculatePercentageVsPercentagePoints(nums[1], nums[2])
    MsgBox(report, "Percentage Change vs Percentage-Point Change", "Iconi")
}

CalculatePercentageVsPercentagePoints(val1, val2) {
    v1 := Float(val1)
    v2 := Float(val2)
    
    ppDiff := v2 - v1
    if (v1 = 0)
        relPct := 0.0
    else
        relPct := ((v2 - v1) / v1) * 100
        
    return Format("{:0.2f}% -> {:0.2f}%:`n• Percentage-Point (pp) Change: {:+0.2f} pp`n• Relative Percentage Change: {:+0.2f}%", v1, v2, ppDiff, relPct)
}

ProcessCAGR() {
    sel := SafeGetSelection()
    nums := []
    for match in StrSplit(RegExReplace(sel, "[^\d\.\s,]", " "), [" ", "`n", "`r", ","]) {
        if (Trim(match) != "" && IsNumber(match))
            nums.Push(Float(match))
    }
    if (nums.Length < 3) {
        ib := InputBox("Enter Beginning Value, Ending Value, and Number of Years (e.g. '100000 250000 5'):", "CAGR Growth Calculator", "w500 h160")
        if (ib.Result != "OK" || Trim(ib.Value) = "")
            return
        for match in StrSplit(RegExReplace(ib.Value, "[^\d\.\s,]", " "), [" ", "`n", "`r", ","]) {
            if (Trim(match) != "" && IsNumber(match))
                nums.Push(Float(match))
        }
        if (nums.Length < 3)
            return
    }
    report := CalculateCAGR(nums[1], nums[2], nums[3])
    MsgBox(report, "CAGR Calculator", "Iconi")
}

CalculateCAGR(begVal, endVal, numYears) {
    b := Float(begVal)
    e := Float(endVal)
    y := Float(numYears)
    
    if (b <= 0 || e <= 0 || y <= 0)
        return "Invalid parameters for CAGR"
        
    cagr := ((e / b) ** (1 / y) - 1) * 100
    return Format("Beg: {:0.2f} | End: {:0.2f} | Period: {:0.1f} Years`n-> CAGR: {:0.2f}%", b, e, y, cagr)
}

ProcessReverseGST(gstRate) {
    sel := SafeGetSelection()
    num := RegExReplace(sel, "[^\d\.]", "")
    if (!IsNumber(num) || num <= 0) {
        ib := InputBox("Enter total GST-inclusive amount (e.g. 1180):", "Reverse GST Calculator (" . gstRate . "%)", "w460 h150")
        if (ib.Result != "OK" || Trim(ib.Value) = "" || !IsNumber(Trim(ib.Value)))
            return
        num := Trim(ib.Value)
    }
    report := CalculateReverseGST(num, gstRate)
    InsertText(report)
}

ProcessReverseGSTPrompt() {
    ibRate := InputBox("Enter GST Rate percentage (e.g. 5, 12, 18, 28):", "Select GST Rate", "w420 h150")
    if (ibRate.Result != "OK" || Trim(ibRate.Value) = "" || !IsNumber(Trim(ibRate.Value)))
        return
    rate := Float(Trim(ibRate.Value))
    ProcessReverseGST(rate)
}

CalculateReverseGST(totalAmount, gstRate := 18) {
    tot := Float(totalAmount)
    if (tot <= 0)
        return "Invalid amount"
        
    rate := Float(gstRate)
    base := tot / (1 + (rate / 100))
    tax := tot - base
    halfTax := tax / 2
    
    return Format("Total (Incl. {}% GST): ₹{:0.2f}`n• Taxable Base: ₹{:0.2f}`n• GST ({}%): ₹{:0.2f} (CGST: ₹{:0.2f} | SGST: ₹{:0.2f})", rate, tot, base, rate, tax, halfTax, halfTax)
}

CleanToMachineNumber(rawText) {
    txt := Trim(rawText)
    
    ; Check for Indian crore / lakh words
    if RegExMatch(txt, "i)([\d\.]+)\s*(?:cr|crore|crores)", &m) {
        val := Float(m[1]) * 10000000
        return String(Integer(val))
    }
    if RegExMatch(txt, "i)([\d\.]+)\s*(?:l|lakh|lakhs|lac|lacs)", &m) {
        val := Float(m[1]) * 100000
        return String(Integer(val))
    }
    if RegExMatch(txt, "i)([\d\.]+)\s*(?:k|thousand|thousands)", &m) {
        val := Float(m[1]) * 1000
        return String(Integer(val))
    }
    
    ; Check European format (1.250,50 -> 1250.50)
    if RegExMatch(txt, "^\d{1,3}(?:\.\d{3})+,\d{2}$") {
        txt := StrReplace(txt, ".", "")
        txt := StrReplace(txt, ",", ".")
        return txt
    }
    
    ; Standard strip currency and commas
    clean := RegExReplace(txt, "[^\d\.-]", "")
    return clean
}

FormatIndianCommas(num) {
    clean := RegExReplace(String(num), "[^\d\.]", "")
    if (clean = "")
        return "0"
    parts := StrSplit(clean, ".")
    intStr := parts[1]
    decStr := (parts.Length > 1) ? ("." . parts[2]) : ""
    
    len := StrLen(intStr)
    if (len <= 3)
        return intStr . decStr
        
    last3 := SubStr(intStr, len - 2)
    rest := SubStr(intStr, 1, len - 3)
    
    formattedRest := RegExReplace(rest, "\G\d+?(?=(\d{2})+$)", "$0,")
    return formattedRest . "," . last3 . decStr
}

FormatInternationalCommas(num) {
    clean := RegExReplace(String(num), "[^\d\.]", "")
    if (clean = "")
        return "0"
    parts := StrSplit(clean, ".")
    intStr := parts[1]
    decStr := (parts.Length > 1) ? ("." . parts[2]) : ""
    formatted := RegExReplace(intStr, "\G\d+?(?=(\d{3})+$)", "$0,")
    return formatted . decStr
}
